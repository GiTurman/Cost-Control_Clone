import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { HashRouter } from "react-router-dom";
import App from "@/app/App";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Restaurant Cost Control" },
      { name: "description", content: "Restaurant cost control and inventory management." },
    ],
  }),
  component: Index,
  ssr: false,
});

function Index() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;
  return (
    <HashRouter>
      <App />
    </HashRouter>
  );
}

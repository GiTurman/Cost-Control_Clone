import React, { useRef, useState } from 'react';
import { X, Upload, FileSpreadsheet, Loader2, ChefHat } from 'lucide-react';
import { parseKalkulaciFile, ParsedBOMResult } from '../utils/excelImport';
import { Product, Purchase } from '../types';

interface Props {
  open: boolean;
  onClose: () => void;
  existingProducts: Product[];
  purchases: Purchase[];
  onImport: (result: ParsedBOMResult) => void;
}

export const MenuImportModal: React.FC<Props> = ({ open, onClose, existingProducts, purchases, onImport }) => {
  const fileRef = useRef<HTMLInputElement>(null);
  const [parsing, setParsing] = useState(false);
  const [result, setResult] = useState<ParsedBOMResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFile = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setParsing(true);
    setError(null);
    try {
      const r = await parseKalkulaciFile(files[0], existingProducts, purchases);
      setResult(r);
    } catch (e: any) {
      console.error(e);
      setError('ფაილის წაკითხვა ვერ მოხერხდა');
    } finally {
      setParsing(false);
    }
  };

  const reset = () => {
    setResult(null);
    setError(null);
    if (fileRef.current) fileRef.current.value = '';
  };

  const handleClose = () => { reset(); onClose(); };

  const handleConfirm = () => {
    if (!result) return;
    onImport(result);
    reset();
    onClose();
  };

  if (!open) return null;

  const totalIngredients = result?.dishes.reduce((s, d) => s + d.ingredients.length, 0) ?? 0;
  const newProductCount = result?.newProducts.length ?? 0;

  const dishCost = (d: NonNullable<typeof result>['dishes'][number]) => {
    let total = 0;
    let missing = 0;
    for (const ing of d.ingredients) {
      if (ing.lastPrice == null) missing++;
      else total += ing.lastPrice * ing.quantity;
    }
    return { total, missing, count: d.ingredients.length };
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="text-lg font-bold text-gray-900 flex items-center">
            <FileSpreadsheet className="w-5 h-5 mr-2 text-brand-600" />
            კერძების Excel-დან ატვირთვა
          </h3>
          <button onClick={handleClose} className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          <div>
            <input
              ref={fileRef}
              type="file"
              accept=".xlsx,.xls"
              onChange={(e) => handleFile(e.target.files)}
              className="hidden"
            />
            <button
              onClick={() => fileRef.current?.click()}
              className="flex items-center px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-bold hover:bg-brand-700"
            >
              <Upload className="w-4 h-4 mr-2" />
              ფაილის არჩევა
            </button>
          </div>

          {parsing && (
            <div className="flex items-center text-sm text-gray-600">
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ფაილის დამუშავება...
            </div>
          )}

          {error && <div className="text-sm text-red-600">{error}</div>}

          {result && (
            <>
              <div className="bg-brand-50 border border-brand-200 rounded-xl p-4 text-sm text-brand-900">
                <strong>{result.dishes.length}</strong> კერძი ·{' '}
                <strong>{totalIngredients}</strong> ინგრედიენტი ·{' '}
                <strong>{newProductCount}</strong> ახალი პროდუქტი შეიქმნება
              </div>

              <div className="border border-gray-200 rounded-xl overflow-hidden">
                <div className="overflow-auto max-h-[50vh]">
                  <table className="min-w-full text-xs">
                    <thead className="bg-slate-100 sticky top-0">
                      <tr>
                        <th className="px-3 py-2 text-left">კერძი</th>
                        <th className="px-3 py-2 text-left">კატეგორია</th>
                        <th className="px-3 py-2 text-center">ინგრ.</th>
                        <th className="px-3 py-2 text-right">თვითღირებულება</th>
                        <th className="px-3 py-2 text-center">სტატუსი</th>
                      </tr>
                    </thead>
                    <tbody>
                      {result.dishes.map((d, i) => {
                        const c = dishCost(d);
                        let badge = '';
                        let badgeClass = '';
                        if (c.count === 0 || c.missing === c.count) {
                          badge = '❓ ფასი არ მოიძებნა';
                          badgeClass = 'bg-gray-100 text-gray-600';
                        } else if (c.missing > 0) {
                          badge = `⚠️ ${c.missing} ფასი აკლია`;
                          badgeClass = 'bg-amber-100 text-amber-700';
                        } else {
                          badge = '✅ სრულად';
                          badgeClass = 'bg-green-100 text-green-700';
                        }
                        return (
                          <tr key={i} className="border-t border-gray-100">
                            <td className="px-3 py-1.5 font-medium">{d.name}</td>
                            <td className="px-3 py-1.5 text-gray-500">{d.category}</td>
                            <td className="px-3 py-1.5 text-center">{c.count}</td>
                            <td className="px-3 py-1.5 text-right">
                              {c.count > 0 && c.missing < c.count ? `${c.total.toFixed(2)} ₾` : '—'}
                            </td>
                            <td className="px-3 py-1.5 text-center">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${badgeClass}`}>{badge}</span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-100 flex justify-end gap-3">
          <button onClick={handleClose} className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium hover:bg-gray-50">
            გაუქმება
          </button>
          <button
            onClick={handleConfirm}
            disabled={!result || result.dishes.length === 0 || parsing}
            className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-bold hover:bg-brand-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
          >
            <ChefHat className="w-4 h-4 mr-2" />
            ჩატვირთვა {result ? `(${result.dishes.length})` : ''}
          </button>
        </div>
      </div>
    </div>
  );
};

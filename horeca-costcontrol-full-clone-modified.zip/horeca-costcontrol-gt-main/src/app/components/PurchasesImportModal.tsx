import React, { useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { X, Upload, FileSpreadsheet, Loader2, Download } from 'lucide-react';
import { parsePurchaseFile, ParsedPurchase } from '../utils/excelImport';
import { Department } from '../types';

interface Props {
  open: boolean;
  onClose: () => void;
  department: Department;
  onImport: (rows: ParsedPurchase[]) => void;
}

function defaultFromDate(): string {
  const d = new Date();
  d.setMonth(d.getMonth() - 3);
  return d.toISOString().substring(0, 10);
}
function todayStr(): string {
  return new Date().toISOString().substring(0, 10);
}

export const PurchasesImportModal: React.FC<Props> = ({ open, onClose, department, onImport }) => {
  const fileRef = useRef<HTMLInputElement>(null);
  const [parsing, setParsing] = useState(false);
  const [rows, setRows] = useState<ParsedPurchase[]>([]);
  const [fromDate, setFromDate] = useState(defaultFromDate());
  const [toDate, setToDate] = useState(todayStr());
  const [error, setError] = useState<string | null>(null);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setParsing(true);
    setError(null);
    try {
      const all: ParsedPurchase[] = [];
      for (const f of Array.from(files)) {
        const parsed = await parsePurchaseFile(f);
        all.push(...parsed);
      }
      // Override department to current page department
      all.forEach(r => { r.department = department; });
      setRows(all);
    } catch (e: any) {
      console.error(e);
      setError('ფაილის წაკითხვა ვერ მოხერხდა');
    } finally {
      setParsing(false);
    }
  };

  const filtered = useMemo(() => {
    return rows.filter(r => {
      if (fromDate && r.date < fromDate) return false;
      if (toDate && r.date > toDate) return false;
      return true;
    });
  }, [rows, fromDate, toDate]);

  const preview = filtered.slice(0, 100);

  const reset = () => {
    setRows([]);
    setError(null);
    if (fileRef.current) fileRef.current.value = '';
  };

  const handleConfirm = () => {
    if (filtered.length === 0) return;
    onImport(filtered);
    reset();
    onClose();
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const downloadTemplate = () => {
    const headers: any[] = new Array(20).fill('');
    headers[1] = 'თარიღი';
    headers[6] = 'მომწოდებელი';
    headers[8] = 'პროდუქტი';
    headers[9] = 'კატეგორია';
    headers[13] = 'განყოფილება (რესტორანი/ბარი)';
    headers[16] = 'ერთეული';
    headers[17] = 'რაოდენობა';
    headers[18] = 'ფასი';
    headers[19] = 'ჯამი';

    const example: any[] = new Array(20).fill('');
    example[1] = '2025-01-15';
    example[6] = 'შპს მაგალითი';
    example[8] = 'კარტოფილი';
    example[9] = 'ბოსტნეული';
    example[13] = 'რესტორანი';
    example[16] = 'კგ';
    example[17] = 10;
    example[18] = 2.5;
    example[19] = 25;

    const titleRow: any[] = new Array(20).fill('');
    titleRow[1] = 'შესყიდვების შაბლონი — მონაცემები იწყება მე-3 სტრიქონიდან';

    const aoa = [titleRow, headers, example];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws['!cols'] = [
      { wch: 4 }, { wch: 14 }, { wch: 6 }, { wch: 6 }, { wch: 6 }, { wch: 6 },
      { wch: 6 }, { wch: 6 }, { wch: 28 }, { wch: 16 }, { wch: 6 }, { wch: 6 },
      { wch: 6 }, { wch: 16 }, { wch: 6 }, { wch: 6 }, { wch: 10 }, { wch: 12 },
      { wch: 10 }, { wch: 12 },
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'შესყიდვა');
    XLSX.writeFile(wb, 'purchases_template.xlsx');
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-5xl max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="text-lg font-bold text-gray-900 flex items-center">
            <FileSpreadsheet className="w-5 h-5 mr-2 text-brand-600" />
            შესყიდვების Excel-დან ატვირთვა
          </h3>
          <button onClick={handleClose} className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          <div className="flex flex-wrap items-end gap-3">
            <div>
              <input
                ref={fileRef}
                type="file"
                multiple
                accept=".xlsx,.xls"
                onChange={(e) => handleFiles(e.target.files)}
                className="hidden"
              />
              <button
                onClick={() => fileRef.current?.click()}
                className="flex items-center px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-bold hover:bg-brand-700"
              >
                <Upload className="w-4 h-4 mr-2" />
                ფაილ(ებ)ის არჩევა
              </button>
            </div>
            <div>
              <button
                onClick={downloadTemplate}
                className="flex items-center px-4 py-2 border border-brand-600 text-brand-700 bg-white rounded-xl text-sm font-bold hover:bg-brand-50"
              >
                <Download className="w-4 h-4 mr-2" />
                შაბლონის ჩამოტვირთვა
              </button>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">თარიღიდან</label>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">თარიღამდე</label>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>
          </div>

          {parsing && (
            <div className="flex items-center text-sm text-gray-600">
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ფაილის დამუშავება...
            </div>
          )}

          {error && <div className="text-sm text-red-600">{error}</div>}

          {rows.length > 0 && (
            <div className="text-sm text-gray-700">
              სულ: <strong>{rows.length}</strong> ჩანაწერი · ფილტრის შემდეგ: <strong>{filtered.length}</strong>
            </div>
          )}

          {preview.length > 0 && (
            <div className="border border-gray-200 rounded-xl overflow-hidden">
              <div className="overflow-auto max-h-[50vh]">
                <table className="min-w-full text-xs">
                  <thead className="bg-slate-100 sticky top-0">
                    <tr>
                      <th className="px-2 py-2 text-left">თარიღი</th>
                      <th className="px-2 py-2 text-left">პროდუქტი</th>
                      <th className="px-2 py-2 text-left">კატეგორია</th>
                      <th className="px-2 py-2 text-center">ერთ.</th>
                      <th className="px-2 py-2 text-right">რაოდ.</th>
                      <th className="px-2 py-2 text-right">ფასი</th>
                      <th className="px-2 py-2 text-right">ჯამი</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.map((r, i) => (
                      <tr key={i} className="border-t border-gray-100">
                        <td className="px-2 py-1">{r.date}</td>
                        <td className="px-2 py-1">{r.productName}</td>
                        <td className="px-2 py-1 text-gray-500">{r.category}</td>
                        <td className="px-2 py-1 text-center">{r.unit}</td>
                        <td className="px-2 py-1 text-right">{r.quantity}</td>
                        <td className="px-2 py-1 text-right">{r.price.toFixed(2)}</td>
                        <td className="px-2 py-1 text-right font-semibold">{r.total.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {filtered.length > preview.length && (
                <div className="px-3 py-2 text-xs text-gray-500 bg-gray-50 border-t border-gray-200">
                  ნაჩვენებია პირველი {preview.length} ჩანაწერი {filtered.length}-დან
                </div>
              )}
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-100 flex justify-end gap-3">
          <button onClick={handleClose} className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium hover:bg-gray-50">
            გაუქმება
          </button>
          <button
            onClick={handleConfirm}
            disabled={filtered.length === 0 || parsing}
            className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-bold hover:bg-brand-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            ჩატვირთვა ({filtered.length})
          </button>
        </div>
      </div>
    </div>
  );
};

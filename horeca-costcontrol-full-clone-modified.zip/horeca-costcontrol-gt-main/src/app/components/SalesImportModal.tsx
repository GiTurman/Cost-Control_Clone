import React, { useMemo, useRef, useState } from 'react';
import { X, Upload, FileSpreadsheet, Loader2, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { parseSalesFile, ParsedSaleRow } from '../utils/excelImport';
import { Dish } from '../types';

interface Props {
  open: boolean;
  onClose: () => void;
  dishes: Dish[];
  onImport: (rows: ParsedSaleRow[]) => void;
}

function defaultFromDate(): string {
  const d = new Date();
  d.setMonth(d.getMonth() - 3);
  return d.toISOString().substring(0, 10);
}
function todayStr(): string {
  return new Date().toISOString().substring(0, 10);
}

export const SalesImportModal: React.FC<Props> = ({ open, onClose, dishes, onImport }) => {
  const fileRef = useRef<HTMLInputElement>(null);
  const [parsing, setParsing] = useState(false);
  const [rows, setRows] = useState<ParsedSaleRow[]>([]);
  const [fromDate, setFromDate] = useState(defaultFromDate());
  const [toDate, setToDate] = useState(todayStr());
  const [error, setError] = useState<string | null>(null);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setParsing(true);
    setError(null);
    try {
      const all: ParsedSaleRow[] = [];
      for (const f of Array.from(files)) {
        const parsed = await parseSalesFile(f, dishes);
        all.push(...parsed);
      }
      setRows(all);
    } catch (e) {
      console.error(e);
      setError('ფაილის წაკითხვა ვერ მოხერხდა');
    } finally {
      setParsing(false);
    }
  };

  const filtered = useMemo(() => {
    return rows.filter(r => {
      if (fromDate && r.date < fromDate) return false;
      if (toDate && r.date > toDate) return false;
      return true;
    });
  }, [rows, fromDate, toDate]);

  const preview = filtered.slice(0, 200);
  const matchedCount = filtered.filter(r => r.dishId).length;
  const unmatchedCount = filtered.length - matchedCount;

  const reset = () => {
    setRows([]);
    setError(null);
    if (fileRef.current) fileRef.current.value = '';
  };

  const applyManualMatch = (rowIdx: number, dishId: string) => {
    const dish = dishes.find(d => d.id === dishId);
    setRows(prev => {
      const targetKey = preview[rowIdx];
      return prev.map(r =>
        r === targetKey ? { ...r, dishId: dish?.id ?? null, dishName: dish?.name ?? null, department: dish?.department } : r
      );
    });
  };

  const handleConfirm = () => {
    const toImport = filtered.filter(r => r.dishId);
    if (toImport.length === 0) return;
    onImport(toImport);
    reset();
    onClose();
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-6xl max-h-[90vh] flex flex-col">
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="text-lg font-bold text-gray-900 flex items-center">
            <FileSpreadsheet className="w-5 h-5 mr-2 text-brand-600" />
            გაყიდვების Excel-დან ატვირთვა
          </h3>
          <button onClick={handleClose} className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          <div className="flex flex-wrap items-end gap-3">
            <div>
              <input
                ref={fileRef}
                type="file"
                multiple
                accept=".xlsx,.xls"
                onChange={(e) => handleFiles(e.target.files)}
                className="hidden"
              />
              <button
                onClick={() => fileRef.current?.click()}
                className="flex items-center px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-bold hover:bg-brand-700"
              >
                <Upload className="w-4 h-4 mr-2" />
                ფაილ(ებ)ის არჩევა
              </button>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">თარიღიდან</label>
              <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">თარიღამდე</label>
              <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm" />
            </div>
          </div>

          {parsing && (
            <div className="flex items-center text-sm text-gray-600">
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ფაილის დამუშავება (დღეების და კერძების მიხედვით ჯგუფდება)...
            </div>
          )}

          {error && <div className="text-sm text-red-600">{error}</div>}

          {rows.length > 0 && (
            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-1.5 text-green-700">
                <CheckCircle2 className="w-4 h-4" /> დამთხვევა: <strong>{matchedCount}</strong>
              </div>
              <div className="flex items-center gap-1.5 text-red-600">
                <AlertTriangle className="w-4 h-4" /> ვერ მოინახა შესატყვისი: <strong>{unmatchedCount}</strong>
              </div>
              <div className="text-gray-500">სულ ჩანაწერი (დღე+კერძი): <strong>{filtered.length}</strong></div>
            </div>
          )}

          {preview.length > 0 && (
            <div className="border border-gray-200 rounded-xl overflow-hidden">
              <div className="overflow-auto max-h-[50vh]">
                <table className="min-w-full text-xs">
                  <thead className="bg-slate-100 sticky top-0">
                    <tr>
                      <th className="px-2 py-2 text-left">თარიღი</th>
                      <th className="px-2 py-2 text-left">დასახელება ფაილში</th>
                      <th className="px-2 py-2 text-right">რაოდ.</th>
                      <th className="px-2 py-2 text-left">დაკავშირებული კერძი</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.map((r, i) => (
                      <tr key={i} className={`border-t border-gray-100 ${!r.dishId ? 'bg-red-50' : ''}`}>
                        <td className="px-2 py-1">{r.date}</td>
                        <td className="px-2 py-1 text-gray-600">{r.rawName}</td>
                        <td className="px-2 py-1 text-right">{r.quantity}</td>
                        <td className="px-2 py-1">
                          {r.dishId ? (
                            <span className="text-green-700 font-medium">{r.dishName}</span>
                          ) : (
                            <select
                              defaultValue=""
                              onChange={(e) => applyManualMatch(i, e.target.value)}
                              className="border border-red-300 rounded px-1.5 py-0.5 text-xs text-red-700 bg-white max-w-[220px]"
                            >
                              <option value="" disabled>⚠️ ვერ მოიძებნა — აირჩიე ხელით</option>
                              {dishes.map(d => (
                                <option key={d.id} value={d.id}>{d.name}</option>
                              ))}
                            </select>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {filtered.length > preview.length && (
                <div className="px-3 py-2 text-xs text-gray-500 bg-gray-50 border-t border-gray-200">
                  ნაჩვენებია პირველი {preview.length} ჩანაწერი {filtered.length}-დან
                </div>
              )}
            </div>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-100 flex justify-end gap-3">
          <button onClick={handleClose} className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-medium hover:bg-gray-50">
            გაუქმება
          </button>
          <button
            onClick={handleConfirm}
            disabled={matchedCount === 0 || parsing}
            className="px-4 py-2 bg-brand-600 text-white rounded-xl text-sm font-bold hover:bg-brand-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            ჩატვირთვა ({matchedCount})
          </button>
        </div>
      </div>
    </div>
  );
};

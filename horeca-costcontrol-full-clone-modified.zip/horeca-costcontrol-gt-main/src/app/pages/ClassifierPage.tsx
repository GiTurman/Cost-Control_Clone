import React, { useState, useCallback } from 'react';
import * as XLSX from 'xlsx';
import {
  Upload, Download, FileSearch, BrainCircuit, Scale, FolderTree,
  CheckCircle2, Loader2, Building2,
} from 'lucide-react';
import { formatCurrency } from '../i18n';

const BACKEND_URL = 'http://localhost:3001';

type Dept =
  | 'სამზარეულო' | 'ჰაუსქიფინგი' | 'საინჟინრო' | 'დესკი'
  | 'ბარი' | 'ძირითადი საშუალება' | 'სხვა ხარჯები';

const DEPARTMENTS: readonly Dept[] = [
  'სამზარეულო', 'ბარი', 'ჰაუსქიფინგი', 'საინჟინრო',
  'დესკი', 'ძირითადი საშუალება', 'სხვა ხარჯები',
];

interface Classification { c1: string; c2: string; c3: string; }

interface RawRow {
  date: string; productName: string; classShort: string; deptRaw: string;
  unit: string; qty: number; price: number; total: number; supplier: string;
}

interface EnrichedRow extends RawRow {
  c1: string; c2: string; c3: string; baseUnit: string; baseQty: number;
}

interface Progress { stage: 0 | 1 | 2 | 3 | 4; done: number; total: number; batch: number; }

const STAGES = [
  { id: 1, label: 'ფაილის წაკითხვა და დედუპლიკაცია', icon: FileSearch },
  { id: 2, label: 'AI კლასიფიკაცია (C1 / C2 / C3)', icon: BrainCircuit },
  { id: 3, label: 'ერთეულების ტრანსფორმაცია', icon: Scale },
  { id: 4, label: 'დეპარტამენტების ფაილების მომზადება', icon: FolderTree },
] as const;

const DEPT_COLOR: Record<string, string> = {
  'სამზარეულო': 'border-green-200 bg-green-50 text-green-800',
  'ბარი': 'border-emerald-200 bg-emerald-50 text-emerald-800',
  'ჰაუსქიფინგი': 'border-blue-200 bg-blue-50 text-blue-800',
  'საინჟინრო': 'border-orange-200 bg-orange-50 text-orange-800',
  'დესკი': 'border-purple-200 bg-purple-50 text-purple-800',
  'ძირითადი საშუალება': 'border-slate-300 bg-slate-50 text-slate-800',
  'სხვა ხარჯები': 'border-gray-200 bg-gray-50 text-gray-700',
};

function toISODate(v: unknown): string {
  if (v == null || v === '') return '';
  if (typeof v === 'number') {
    const d = XLSX.SSF.parse_date_code(v);
    if (d) return `${d.y}-${String(d.m).padStart(2, '0')}-${String(d.d).padStart(2, '0')}`;
  }
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  const s = String(v).trim();
  const m = s.match(/^(\d{4})[./-](\d{1,2})[./-](\d{1,2})/);
  if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
  const m2 = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})/);
  if (m2) return `${m2[3]}-${m2[2].padStart(2, '0')}-${m2[1].padStart(2, '0')}`;
  return s;
}

function transformUnit(rawUnit: string, qty: number): { baseUnit: string; baseQty: number } {
  const u = (rawUnit || '').trim();
  if (u === 'გრ') return { baseUnit: 'კგ', baseQty: qty / 1000 };
  if (u === 'მლ') return { baseUnit: 'ლ', baseQty: qty / 1000 };
  if (u === 'კილოგრამი' || u === 'კილოგრამი- KG' || u === 'კგ') return { baseUnit: 'კგ', baseQty: qty };
  if (u === 'ცალი' || u === 'ცალი - ADET' || u === 'ც') return { baseUnit: 'ც', baseQty: qty };
  if (u === 'ლიტრი' || u === 'ლიტრა' || u === 'ლ') return { baseUnit: 'ლ', baseQty: qty };
  if (u === 'შეკვ.' || u === 'შეკვრაში ერთი') return { baseUnit: 'შეკვრა', baseQty: qty };
  return { baseUnit: u || 'ც', baseQty: qty };
}

function parseExcel(file: File): Promise<RawRow[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target!.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, defval: '' });
        const out: RawRow[] = [];
        for (let i = 2; i < rows.length; i++) {
          const r = rows[i] as unknown[];
          if (!r || r.length === 0) continue;
          const productName = String(r[8] ?? '').trim();
          if (!productName) continue;
          out.push({
            date: toISODate(r[1]),
            productName,
            classShort: String(r[9] ?? '').trim(),
            deptRaw: String(r[13] ?? '').trim(),
            unit: String(r[16] ?? '').trim(),
            qty: Number(r[17]) || 0,
            price: Number(r[18]) || 0,
            total: Number(r[19]) || 0,
            supplier: String(r[6] ?? '').trim(),
          });
        }
        resolve(out);
      } catch (err) { reject(err); }
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsArrayBuffer(file);
  });
}


export const ClassifierPage: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [enriched, setEnriched] = useState<EnrichedRow[]>([]);
  const [progress, setProgress] = useState<Progress>({ stage: 0, done: 0, total: 0, batch: 0 });
  const [running, setRunning] = useState(false);
  const [backendError, setBackendError] = useState<string | null>(null);

  const run = useCallback(async () => {
    if (!file) return;
    setRunning(true);
    setEnriched([]);
    setBackendError(null);

    // Stage 1 (client) — parse Excel
    setProgress({ stage: 1, done: 0, total: 0, batch: 0 });
    const raw = await parseExcel(file);

    // Send to local agent backend; consume SSE progress stream
    try {
      const response = await fetch(`${BACKEND_URL}/classify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rows: raw }),
      });

      if (!response.ok || !response.body) {
        throw new Error(`backend error ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split('\n\n');
        buffer = events.pop() ?? '';
        for (const block of events) {
          const line = block.trim();
          if (!line.startsWith('data:')) continue;
          const ev = JSON.parse(line.slice(5).trim());
          if (ev.type === 'result') {
            setEnriched(ev.enriched as EnrichedRow[]);
          } else if (ev.type === 'error') {
            setBackendError(ev.message || 'backend error');
          } else if (ev.stage) {
            setProgress({
              stage: ev.stage,
              done: ev.done ?? (ev.status === 'done' ? (ev.total ?? 0) : 0),
              total: ev.total ?? 0,
              batch: ev.batches ?? 0,
            });
          }
        }
      }
    } catch (err) {
      setBackendError(
        'ლოკალურ backend-თან კავშირი ვერ მოხერხდა. დარწმუნდი რომ გაშვებულია: npm run dev (localhost:3001)'
      );
    } finally {
      setRunning(false);
    }
  }, [file]);

  const grouped = enriched.reduce<Record<string, EnrichedRow[]>>((acc, r) => {
    (acc[r.c3] ||= []).push(r);
    return acc;
  }, {});

  const exportDept = (dept: string, rows: EnrichedRow[]) => {
    const sheetData = rows.map(r => ({
      'თარიღი': r.date,
      'დასახელება (C1)': r.c1,
      'სეგმენტი (C2)': r.c2,
      'დეპარტამენტი (C3)': r.c3,
      'რაოდენობა': r.baseQty,
      'ერთეული': r.baseUnit,
      'ფასი': r.price,
      'ჯამი': r.total,
      'მომწოდებელი': r.supplier,
      'ორიგინალი': r.productName,
    }));
    const ws = XLSX.utils.json_to_sheet(sheetData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, dept.slice(0, 28));
    XLSX.writeFile(wb, `${dept}_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const pct = progress.total > 0 ? (progress.done / progress.total) * 100 : 0;

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto w-full space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 tracking-tight">შემსყიდველის ასისტენტი</h2>
        <p className="text-sm text-gray-500 mt-1">აგენტური ორკესტრატორი — შესყიდვების ავტომატური დაკლასება და დეპარტამენტებად დაყოფა</p>
      </div>

      {/* Zone A — Upload */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-wrap gap-4 items-center">
          <label className="inline-flex items-center gap-2 border border-gray-300 rounded-lg px-4 py-2 text-sm font-medium hover:bg-gray-50 cursor-pointer">
            <Upload className="w-4 h-4" />
            {file ? file.name : 'Excel ფაილის არჩევა'}
            <input type="file" accept=".xlsx,.xls" className="hidden"
              onChange={e => setFile(e.target.files?.[0] ?? null)} disabled={running} />
          </label>
          <button onClick={run} disabled={!file || running}
            className="inline-flex items-center gap-2 bg-brand-600 text-white rounded-lg px-5 py-2 text-sm font-bold hover:bg-brand-700 disabled:bg-gray-300 disabled:cursor-not-allowed">
            {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <BrainCircuit className="w-4 h-4" />}
            {running ? 'მუშაობს...' : 'ანალიზის დაწყება'}
          </button>
        </div>
      </div>

      {backendError && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-700">
          ⚠️ {backendError}
        </div>
      )}

      {/* Zone B — Agent Pipeline */}
      {progress.stage > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 space-y-3">
          <h3 className="text-lg font-bold text-gray-900 mb-2">აგენტის სამუშაო პროცესი</h3>
          {STAGES.map(st => {
            const active = progress.stage === st.id && running;
            const done = progress.stage > st.id || (progress.stage === st.id && !running && enriched.length > 0);
            const Icon = st.icon;
            return (
              <div key={st.id}
                className={`flex items-center gap-3 rounded-xl border p-3 transition-all ${
                  active ? 'border-brand-500 ring-2 ring-brand-100 bg-brand-50/30'
                  : done ? 'border-green-200 bg-green-50'
                  : 'border-gray-200 opacity-60'
                }`}>
                <div className="shrink-0">
                  {active ? <Loader2 className="w-5 h-5 text-brand-600 animate-spin" />
                    : done ? <CheckCircle2 className="w-5 h-5 text-green-500" />
                    : <Icon className="w-5 h-5 text-gray-400" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-gray-800">ეტაპი {st.id}/4: {st.label}</div>
                  {st.id === 1 && progress.stage >= 1 && (
                    <div className="text-xs text-gray-500 mt-0.5">{progress.total} ჩანაწერი → {progress.stage === 1 ? progress.done : ''} {progress.stage >= 1 ? 'უნიკალური დასახელება' : ''}</div>
                  )}
                  {st.id === 2 && active && (
                    <>
                      <div className="text-xs text-gray-500 mt-0.5">{progress.done} / {progress.total} დასახელება · batch {progress.batch}</div>
                      <div className="h-1.5 bg-gray-100 rounded-full mt-1.5 overflow-hidden">
                        <div className="h-full bg-brand-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
                      </div>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Zone C — Results */}
      {enriched.length > 0 && !running && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 space-y-5">
          <h3 className="text-lg font-bold text-gray-900">დეპარტამენტები — ჩამოტვირთვა</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {DEPARTMENTS.filter(d => grouped[d]?.length).map(dept => {
              const rows = grouped[dept];
              const totalVal = rows.reduce((s, r) => s + r.total, 0);
              return (
                <div key={dept} className={`rounded-xl border p-4 ${DEPT_COLOR[dept] ?? 'border-gray-200 bg-gray-50'}`}>
                  <div className="flex items-center gap-2 mb-1">
                    <Building2 className="w-4 h-4 opacity-70" />
                    <span className="text-sm font-bold">{dept}</span>
                  </div>
                  <div className="text-2xl font-black">{rows.length}</div>
                  <div className="text-xs opacity-75 mt-0.5">{formatCurrency(totalVal)}</div>
                  <button onClick={() => exportDept(dept, rows)}
                    className="mt-3 w-full inline-flex items-center justify-center gap-1.5 bg-white/70 hover:bg-white border border-current/20 rounded-lg px-3 py-1.5 text-xs font-bold transition-colors">
                    <Download className="w-3.5 h-3.5" /> ჩამოტვირთვა
                  </button>
                </div>
              );
            })}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="text-gray-400 border-b border-gray-200 text-left">
                  <th className="py-2 px-2 font-medium">C1 (დასახელება)</th>
                  <th className="py-2 px-2 font-medium">C2 (სეგმენტი)</th>
                  <th className="py-2 px-2 font-medium">C3 (დეპ.)</th>
                  <th className="py-2 px-2 font-medium text-right">რაოდ.</th>
                  <th className="py-2 px-2 font-medium">ერთ.</th>
                  <th className="py-2 px-2 font-medium text-right">ფასი</th>
                </tr>
              </thead>
              <tbody>
                {enriched.slice(0, 10).map((r, i) => (
                  <tr key={i} className="border-b border-gray-100">
                    <td className="py-1.5 px-2 text-gray-800 font-medium">{r.c1}</td>
                    <td className="py-1.5 px-2 text-gray-600">{r.c2}</td>
                    <td className="py-1.5 px-2 text-gray-600">{r.c3}</td>
                    <td className="py-1.5 px-2 text-right text-gray-600">{r.baseQty}</td>
                    <td className="py-1.5 px-2 text-gray-500">{r.baseUnit}</td>
                    <td className="py-1.5 px-2 text-right text-gray-600">{formatCurrency(r.price)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

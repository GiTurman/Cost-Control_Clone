import React, { useState, useCallback } from 'react';
import * as XLSX from 'xlsx';
import { useParams } from 'react-router-dom';
import { useAppStore } from '../store';
import { Product, Dish, Ingredient, Department } from '../types';
import {
  ChefHat, Upload, Loader2, CheckCircle2,
  Sparkles, Link2, Save, ChevronDown, ChevronRight, Trash2, Database,
} from 'lucide-react';
import { PASKI_MENU } from '../data/paskiMenu';

const BACKEND_URL = 'http://localhost:3001';
const genId = () => Math.random().toString(36).substring(2, 11);

interface MenuDish { name: string; nameEn: string; category: string; portion: string; price: number; department: Department; }
interface RecipeIng { name: string; qty: number; unit: string; }
interface DraftIng extends RecipeIng { productId: string | null; matchedName: string | null; }
interface DraftDish { tempId: string; name: string; category: string; price: number; department: Department; ingredients: DraftIng[]; }
interface Progress { stage: 0 | 1 | 2; done: number; total: number; }

const STAGES = [
  { id: 1, label: 'რეცეპტების გენერაცია (AI)', icon: Sparkles },
  { id: 2, label: 'ინგრედიენტების მატჩინგი შესყიდვებთან', icon: Link2 },
];

function sheetDepartment(sheetName: string, fallback: Department): Department {
  const s = sheetName.toLowerCase();
  if (s.includes('bar') || s.includes('ბარი')) return 'bar';
  if (s.includes('housekeep') || s.includes('ჰაუსქიფ')) return 'housekeeping';
  if (s.includes('breakfast') || s.includes('საუზმ')) return 'breakfast';
  return fallback;
}

// system operates on base units (კგ/ლ/ც) — AI recipe returns gr/ml/c, must convert
function toBaseUnit(qty: number, unit: string): { qty: number; unit: string } {
  const u = unit.trim().toLowerCase();
  if (u === 'გრ' || u === 'gr' || u === 'g') return { qty: qty / 1000, unit: 'კგ' };
  if (u === 'მლ' || u === 'ml') return { qty: qty / 1000, unit: 'ლ' };
  if (u === 'ც' || u === 'c' || u === 'pcs') return { qty, unit: 'ც' };
  return { qty, unit };
}

function parseMenu(file: File, fallbackDept: Department): Promise<MenuDish[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const wb = XLSX.read(new Uint8Array(e.target!.result as ArrayBuffer), { type: 'array' });
        const out: MenuDish[] = [];
        for (const sheetName of wb.SheetNames) {
          const dept = sheetDepartment(sheetName, fallbackDept);
          const rows = XLSX.utils.sheet_to_json<unknown[]>(wb.Sheets[sheetName], { header: 1, defval: '' });
          let headerSeen = false;
          for (const r of rows) {
            const row = r as unknown[];
            const cat = String(row[0] ?? '').trim();
            const nameGe = String(row[1] ?? '').trim();
            if (!headerSeen) {
              if (cat.includes('კატეგორია') || cat.toLowerCase().includes('category')) headerSeen = true;
              continue;
            }
            if (!nameGe) continue;
            out.push({
              category: cat,
              name: nameGe,
              nameEn: String(row[2] ?? '').trim(),
              portion: String(row[3] ?? '').trim(),
              price: Number(row[4]) || 0,
              department: dept,
            });
          }
        }
        resolve(out);
      } catch (err) { reject(err); }
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsArrayBuffer(file);
  });
}

export const ChefPage: React.FC = () => {
  const { department } = useParams<{ department: string }>();
  const urlDept = (department as Department) || 'restaurant';
  const { addProduct, addDish, getProducts } = useAppStore();
  const products = getProducts();

  const [file, setFile] = useState<File | null>(null);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState<Progress>({ stage: 0, done: 0, total: 0 });
  const [drafts, setDrafts] = useState<DraftDish[]>([]);
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const toggle = (id: string) => setExpanded((p) => ({ ...p, [id]: !p[id] }));

  const run = useCallback(async () => {
    if (!file) return;
    setRunning(true); setDrafts([]); setError(null); setSaved(false);
    setProgress({ stage: 1, done: 0, total: 0 });

    const menu = await parseMenu(file, urlDept);
    const productNames = products.map((p) => p.name);

    try {
      const resp = await fetch(`${BACKEND_URL}/recipes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dishes: menu.map((m) => ({ name: m.name, portion: m.portion })),
          products: productNames,
        }),
      });
      if (!resp.ok || !resp.body) throw new Error(`backend ${resp.status}`);

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let recipes: Record<string, RecipeIng[]> = {};
      let matchMap: Record<string, string | null> = {};

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split('\n\n');
        buffer = events.pop() ?? '';
        for (const block of events) {
          const line = block.trim();
          if (!line.startsWith('data:')) continue;
          const ev = JSON.parse(line.slice(5).trim());
          if (ev.type === 'result') { recipes = ev.recipes; matchMap = ev.matchMap; }
          else if (ev.type === 'error') setError(ev.message);
          else if (ev.stage) setProgress({ stage: ev.stage, done: ev.done ?? 0, total: ev.total ?? 0 });
        }
      }

      const nameToProduct = new Map(products.map((p) => [p.name, p]));
      const built: DraftDish[] = menu.map((m) => ({
        tempId: genId(),
        name: m.name,
        category: m.category,
        price: m.price,
        department: m.department,
        ingredients: (recipes[m.name] || []).map((ing) => {
          const base = toBaseUnit(ing.qty, ing.unit);
          const matched = matchMap[ing.name] || null;
          const prod = matched ? nameToProduct.get(matched) : undefined;
          return { name: ing.name, qty: base.qty, unit: base.unit, productId: prod?.id ?? null, matchedName: matched };
        }),
      }));
      setDrafts(built);
    } catch {
      setError('ლოკალურ backend-თან კავშირი ვერ მოხერხდა (npm run dev, localhost:3001)');
    } finally {
      setRunning(false);
    }
  }, [file, products, urlDept]);

  const loadBuiltIn = () => {
    setError(null); setSaved(false);
    const nameToProduct = new Map(products.map((p) => [p.name, p]));
    const built: DraftDish[] = PASKI_MENU.map((m) => ({
      tempId: genId(),
      name: m.name,
      category: m.category,
      price: m.price,
      department: m.department,
      ingredients: m.ingredients.map((ing) => {
        const prod = nameToProduct.get(ing.name);
        return { name: ing.name, qty: ing.qty, unit: ing.unit, productId: prod?.id ?? null, matchedName: prod ? ing.name : null };
      }),
    }));
    setDrafts(built);
  };

  const removeIng = (dishId: string, idx: number) =>
    setDrafts((ds) => ds.map((d) => d.tempId === dishId
      ? { ...d, ingredients: d.ingredients.filter((_, i) => i !== idx) } : d));

  const editQty = (dishId: string, idx: number, qty: number) =>
    setDrafts((ds) => ds.map((d) => d.tempId === dishId
      ? { ...d, ingredients: d.ingredients.map((ing, i) => i === idx ? { ...ing, qty } : ing) } : d));

  const saveAll = () => {
    const existing = new Map(products.map((p) => [p.name, p]));
    drafts.forEach((d) => {
      const ingredients: Ingredient[] = d.ingredients.map((ing) => {
        let productId = ing.productId;
        if (!productId) {
          const found = existing.get(ing.matchedName ?? ing.name);
          if (found) productId = found.id;
          else {
            const np: Product = {
              id: genId(), name: ing.name, unit: ing.unit,
              category: 'ნედლეული', minBalance: 0, department: d.department,
            };
            addProduct(np);
            existing.set(ing.name, np);
            productId = np.id;
          }
        }
        return { productId: productId!, quantity: ing.qty };
      });
      const dish: Dish = {
        id: genId(), name: d.name, category: d.category,
        ingredients, salePrice: d.price, department: d.department,
      };
      addDish(dish);
    });
    setSaved(true);
  };

  const newProductCount = (() => {
    const have = new Set(products.map((p) => p.name));
    const need = new Set<string>();
    drafts.forEach((d) => d.ingredients.forEach((ing) => {
      if (!ing.productId && !have.has(ing.matchedName ?? ing.name)) need.add(ing.name);
    }));
    return need.size;
  })();

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto w-full space-y-6">
      <div className="flex items-center gap-3">
        <ChefHat className="w-7 h-7 text-brand-600" />
        <div>
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">შეფ მზარეული</h2>
          <p className="text-sm text-gray-500">მენიუს ფაილიდან კალკულაციების ავტომატური გენერაცია</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        <div className="flex flex-wrap gap-4 items-center">
          <label className="inline-flex items-center gap-2 border border-gray-300 rounded-lg px-4 py-2 text-sm font-medium hover:bg-gray-50 cursor-pointer">
            <Upload className="w-4 h-4" />
            {file ? file.name : 'მენიუს Excel ფაილი'}
            <input type="file" accept=".xlsx,.xls" className="hidden"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)} disabled={running} />
          </label>
          <button onClick={run} disabled={!file || running}
            className="inline-flex items-center gap-2 bg-brand-600 text-white rounded-lg px-5 py-2 text-sm font-bold hover:bg-brand-700 disabled:bg-gray-300 disabled:cursor-not-allowed">
            {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            {running ? 'მუშაობს...' : 'კალკულაციების გენერაცია (AI, საჭიროებს backend-ს)'}
          </button>
          <div className="w-px h-8 bg-gray-200" />
          <button onClick={loadBuiltIn} disabled={running}
            className="inline-flex items-center gap-2 bg-green-600 text-white rounded-lg px-5 py-2 text-sm font-bold hover:bg-green-700 disabled:bg-gray-300">
            <Database className="w-4 h-4" />
            Paski მენიუს ჩატვირთვა (154 კერძი, backend არ სჭირდება)
          </button>
        </div>
        <p className="text-xs text-gray-400 mt-2">sheet-ის მიხედვით ავტომატურად: Food→რესტორანი, Bar→ბარი</p>
      </div>

      {error && <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-700">⚠️ {error}</div>}

      {progress.stage > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 space-y-3">
          <h3 className="text-lg font-bold text-gray-900 mb-2">აგენტის სამუშაო პროცესი</h3>
          {STAGES.map((st) => {
            const active = progress.stage === st.id && running;
            const done = progress.stage > st.id || (progress.stage === st.id && !running && drafts.length > 0);
            const Icon = st.icon;
            return (
              <div key={st.id} className={`flex items-center gap-3 rounded-xl border p-3 transition-all ${
                active ? 'border-brand-500 ring-2 ring-brand-100 bg-brand-50/30'
                : done ? 'border-green-200 bg-green-50' : 'border-gray-200 opacity-60'}`}>
                {active ? <Loader2 className="w-5 h-5 text-brand-600 animate-spin" />
                  : done ? <CheckCircle2 className="w-5 h-5 text-green-500" />
                  : <Icon className="w-5 h-5 text-gray-400" />}
                <div className="flex-1">
                  <div className="text-sm font-semibold text-gray-800">ეტაპი {st.id}/2: {st.label}</div>
                  {st.id === 1 && active && progress.total > 0 && (
                    <div className="text-xs text-gray-500 mt-0.5">{progress.done} / {progress.total} კერძი</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {drafts.length > 0 && !running && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <h3 className="text-lg font-bold text-gray-900">{drafts.length} კერძი — შეამოწმე და შეასწორე</h3>
            <button onClick={saveAll} disabled={saved}
              className="inline-flex items-center gap-2 bg-green-600 text-white rounded-lg px-5 py-2 text-sm font-bold hover:bg-green-700 disabled:bg-gray-300">
              <Save className="w-4 h-4" />
              {saved ? 'შენახულია ✓' : `მენიუში დამატება (${newProductCount} ახალი პროდუქტი)`}
            </button>
          </div>

          <div className="space-y-1.5">
            {drafts.map((d) => (
              <div key={d.tempId} className="border border-gray-200 rounded-xl overflow-hidden">
                <button onClick={() => toggle(d.tempId)}
                  className="w-full flex items-center gap-2 px-4 py-2.5 hover:bg-gray-50 text-left">
                  {expanded[d.tempId] ? <ChevronDown className="w-4 h-4 text-gray-400" /> : <ChevronRight className="w-4 h-4 text-gray-400" />}
                  <span className="font-semibold text-gray-800 flex-1">{d.name}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-500">{d.department}</span>
                  <span className="text-xs text-gray-400">{d.ingredients.length} ინგრედ.</span>
                  <span className="text-sm font-bold text-gray-700">{d.price} ₾</span>
                </button>
                {expanded[d.tempId] && (
                  <div className="px-4 pb-3 bg-gray-50/50">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="text-gray-400 border-b border-gray-200">
                          <th className="text-left py-1.5 font-medium">ინგრედიენტი</th>
                          <th className="text-right py-1.5 font-medium w-20">რაოდ.</th>
                          <th className="text-center py-1.5 font-medium w-14">ერთ.</th>
                          <th className="text-left py-1.5 font-medium">შესყიდვის მატჩი</th>
                          <th className="w-8"></th>
                        </tr>
                      </thead>
                      <tbody>
                        {d.ingredients.map((ing, i) => (
                          <tr key={i} className="border-b border-gray-100 last:border-0">
                            <td className="py-1 text-gray-700 font-medium">{ing.name}</td>
                            <td className="py-1 text-right">
                              <input type="number" step="0.001" value={ing.qty}
                                onChange={(e) => editQty(d.tempId, i, Number(e.target.value))}
                                className="w-20 text-right border border-gray-200 rounded px-1 py-0.5" />
                            </td>
                            <td className="py-1 text-center text-gray-500">{ing.unit}</td>
                            <td className="py-1">
                              {ing.matchedName
                                ? <span className="text-green-600">{ing.matchedName}</span>
                                : <span className="text-amber-500">ახალი პროდუქტი</span>}
                            </td>
                            <td className="py-1 text-center">
                              <button onClick={() => removeIng(d.tempId, i)} className="text-red-400 hover:text-red-600">
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

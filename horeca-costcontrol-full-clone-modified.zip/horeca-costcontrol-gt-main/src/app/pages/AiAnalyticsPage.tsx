import React, { useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAppStore } from '../store';
import { t, formatCurrency } from '../i18n';
import { 
  BrainCircuit, LineChart as LineChartIcon, ShieldAlert, AlertCircle, PackageOpen, 
  CheckCircle, TrendingUp, TrendingDown, Users, SearchX, ArchiveX, Scale, Download, Search, Filter,
  CalendarRange, Minus, Sparkles, Loader2, MessageCircleQuestion
} from 'lucide-react';

const BACKEND_URL = 'http://localhost:3001';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import * as XLSX from 'xlsx';

export const AiAnalyticsPage: React.FC = () => {
  const { language, getProducts, getPurchases, getSales, getDishes, getInventoryAudits } = useAppStore();
  const products = getProducts();
  const purchases = getPurchases();
  const sales = getSales();
  const dishes = getDishes();
  const inventoryAudits = getInventoryAudits();

  // Filters State
  const [priceSearchTerm, setPriceSearchTerm] = useState('');
  const [priceTrendFilter, setPriceTrendFilter] = useState<'all' | 'increase' | 'decrease'>('all');
  const [anomalyTypeFilter, setAnomalyTypeFilter] = useState<'all' | 'critical' | 'warning' | 'info'>('all');
  const [expandedPriceProductId, setExpandedPriceProductId] = useState<string | null>(null);

  const [insightQuestion, setInsightQuestion] = useState('');
  const [insightAnswer, setInsightAnswer] = useState<string | null>(null);
  const [insightLoading, setInsightLoading] = useState(false);
  const [insightError, setInsightError] = useState<string | null>(null);
  const [periodDetailsOpen, setPeriodDetailsOpen] = useState(false);

  const navigate = useNavigate();
  const { restaurantId } = useParams<{ restaurantId: string }>();

  const handlePriceRowClick = (productId: string) => {
    if (expandedPriceProductId === productId) {
      const prod = products.find(p => p.id === productId);
      const dept = prod?.department || 'restaurant';
      const effDept = (dept === 'breakfast') ? 'restaurant' : dept;
      const base = restaurantId
        ? `/HORECA/COSTCONTROL/${restaurantId}/${effDept}/purchases`
        : `/${effDept}/purchases`;
      navigate(`${base}?productId=${productId}`);
    } else {
      setExpandedPriceProductId(productId);
    }
  };


  const CHART_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  // Anchor "today" to the latest date actually present in the data,
  // not the browser's system clock — avoids empty "current period" cards
  // when live data hasn't caught up to the real calendar date yet.
  const latestDataDate = useMemo(() => {
    const allDates = [...purchases.map(p => p.date), ...sales.map(s => s.date)].filter(Boolean);
    if (!allDates.length) return new Date();
    const maxStr = allDates.reduce((a, b) => (a > b ? a : b));
    const d = new Date(maxStr);
    return isNaN(d.getTime()) ? new Date() : d;
  }, [purchases, sales]);

  // ========= PERIOD COMPARISON (user-selectable) =========
  const fmtDate = (d: Date) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  };
  const monthRange = (yr: number, mo: number): [string, string] => {
    const s = new Date(yr, mo, 1);
    const e = new Date(yr, mo + 1, 0);
    return [fmtDate(s), fmtDate(e)];
  };
  const quarterRange = (yr: number, q: number): [string, string] => {
    const s = new Date(yr, q * 3, 1);
    const e = new Date(yr, q * 3 + 3, 0);
    return [fmtDate(s), fmtDate(e)];
  };
  const yearRange = (yr: number): [string, string] => [`${yr}-01-01`, `${yr}-12-31`];
  const seasonRange = (yr: number): [string, string] => [`${yr - 1}-12-01`, `${yr}-04-30`];

  const defaultCurrentMonth = monthRange(latestDataDate.getFullYear(), latestDataDate.getMonth());
  const defaultPrevMonthDate = new Date(latestDataDate.getFullYear(), latestDataDate.getMonth() - 1, 1);
  const defaultPrevMonth = monthRange(defaultPrevMonthDate.getFullYear(), defaultPrevMonthDate.getMonth());

  const [periodAFrom, setPeriodAFrom] = useState(defaultCurrentMonth[0]);
  const [periodATo, setPeriodATo] = useState(defaultCurrentMonth[1]);
  const [periodBFrom, setPeriodBFrom] = useState(defaultPrevMonth[0]);
  const [periodBTo, setPeriodBTo] = useState(defaultPrevMonth[1]);

  const applyPreset = (aRange: [string, string], bRange: [string, string]) => {
    setPeriodAFrom(aRange[0]); setPeriodATo(aRange[1]);
    setPeriodBFrom(bRange[0]); setPeriodBTo(bRange[1]);
  };

  const presets = useMemo(() => {
    const y = latestDataDate.getFullYear();
    const m = latestDataDate.getMonth();
    const q = Math.floor(m / 3);
    const prevMonthDate = new Date(y, m - 1, 1);
    return [
      { label: language === 'ka' ? 'თვე vs წინა თვე' : 'Month vs Prev Month', a: monthRange(y, m), b: monthRange(prevMonthDate.getFullYear(), prevMonthDate.getMonth()) },
      { label: language === 'ka' ? 'თვე vs წინა წლის იგივე თვე' : 'Month vs Same Month LY', a: monthRange(y, m), b: monthRange(y - 1, m) },
      { label: language === 'ka' ? 'კვარტალი vs წინა წლის კვარტალი' : 'Quarter vs Same Q LY', a: quarterRange(y, q), b: quarterRange(y - 1, q) },
      { label: language === 'ka' ? 'წელი vs წინა წელი' : 'Year vs Prev Year', a: yearRange(y), b: yearRange(y - 1) },
      { label: language === 'ka' ? 'სეზონი vs წინა სეზონი' : 'Season vs Prev Season', a: seasonRange(y), b: seasonRange(y - 1) },
    ];
  }, [latestDataDate, language]);

  const selectedComparison = useMemo(() => {
    const sumPurchases = (s: string, e: string) =>
      purchases.filter(p => p.date >= s && p.date <= e).reduce((sum, p) => sum + (p.total || 0), 0);
    const curTotal = sumPurchases(periodAFrom, periodATo);
    const prvTotal = sumPurchases(periodBFrom, periodBTo);
    const diff = prvTotal > 0 ? ((curTotal - prvTotal) / prvTotal) * 100 : (curTotal > 0 ? 100 : 0);
    return {
      currentRange: [periodAFrom, periodATo] as [string, string],
      previousRange: [periodBFrom, periodBTo] as [string, string],
      purchases: { current: curTotal, previous: prvTotal, diff },
    };
  }, [purchases, periodAFrom, periodATo, periodBFrom, periodBTo]);

  const handleAskInsight = async () => {
    const question = insightQuestion.trim();
    if (!question) return;
    setInsightLoading(true);
    setInsightError(null);
    setInsightAnswer(null);
    try {
      const topProducts = products
        .map(p => ({
          name: p.name,
          totalSpend: purchases.filter(pur => pur.productId === p.id).reduce((s, pur) => s + pur.total, 0),
        }))
        .filter(p => p.totalSpend > 0)
        .sort((a, b) => b.totalSpend - a.totalSpend)
        .slice(0, 8);

      const context = {
        selectedComparison: {
          periodA: `${periodAFrom} → ${periodATo}`,
          periodB: `${periodBFrom} → ${periodBTo}`,
          periodATotal: selectedComparison.purchases.current,
          periodBTotal: selectedComparison.purchases.previous,
          changePercent: Number(selectedComparison.purchases.diff.toFixed(1)),
        },
        topProducts,
      };

      const resp = await fetch(`${BACKEND_URL}/analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, context }),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || `backend ${resp.status}`);
      setInsightAnswer(data.answer);
    } catch {
      setInsightError('ლოკალურ backend-თან კავშირი ვერ მოხერხდა (npm run dev, localhost:3001)');
    } finally {
      setInsightLoading(false);
    }
  };


  // Free, deterministic variance-bridge analysis — no AI/API call.
  // Shows which specific products drove the change between the two periods.
  const getPeriodDrivers = (currentRange: [string, string], previousRange: [string, string]) => {
    const [cs, ce] = currentRange;
    const [ps, pe] = previousRange;

    const sumByProduct = (s: string, e: string) => {
      const map: Record<string, { qty: number; total: number }> = {};
      purchases.filter(p => p.date >= s && p.date <= e).forEach(p => {
        const entry = map[p.productId] || { qty: 0, total: 0 };
        entry.qty += p.quantity;
        entry.total += p.total;
        map[p.productId] = entry;
      });
      return map;
    };

    const curMap = sumByProduct(cs, ce);
    const prvMap = sumByProduct(ps, pe);
    const allIds = new Set([...Object.keys(curMap), ...Object.keys(prvMap)]);

    const drivers = Array.from(allIds).map(productId => {
      const product = products.find(p => p.id === productId);
      const cur = curMap[productId] || { qty: 0, total: 0 };
      const prv = prvMap[productId] || { qty: 0, total: 0 };
      return {
        productId,
        name: product?.name || (language === 'ka' ? 'უცნობი პროდუქტი' : 'Unknown product'),
        curTotal: cur.total,
        prvTotal: prv.total,
        delta: cur.total - prv.total,
        curQty: cur.qty,
        prvQty: prv.qty,
      };
    });

    return drivers.sort((a, b) => Math.abs(b.delta) - Math.abs(a.delta)).slice(0, 8);
  };


  const priceChartDataAndLines = useMemo(() => {
    const topProducts = products
      .map(p => {
        const totalSpend = purchases
          .filter(pur => pur.productId === p.id)
          .reduce((sum, pur) => sum + pur.total, 0);
        return { ...p, totalSpend };
      })
      .filter(p => p.totalSpend > 0)
      .sort((a, b) => b.totalSpend - a.totalSpend)
      .slice(0, 5);

    if (topProducts.length === 0) return { data: [], lines: [] };

    const sortedDates = [...new Set(purchases.map(p => p.date))].sort();

    const data = sortedDates.map(date => {
      const point: any = { date };
      topProducts.forEach(tp => {
        const pur = purchases.find(p => p.productId === tp.id && p.date === date);
        if (pur) {
          point[tp.name] = pur.price;
        }
      });
      return point;
    });

    return { data, lines: topProducts.map(tp => tp.name) };
  }, [products, purchases]);

  const priceStats = useMemo(() => {
    const statsArray: Array<{ id: string; name: string; avgPrice: number; lastPrice: number; diffPercent: number }> = [];

    products.forEach(p => {
      const pPurchases = purchases
        .filter(pur => pur.productId === p.id)
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      
      if (pPurchases.length > 0) {
        const sumPrice = pPurchases.reduce((sum, pur) => sum + pur.price, 0);
        const avgPrice = sumPrice / pPurchases.length;
        const lastPrice = pPurchases[pPurchases.length - 1].price;
        
        let diffPercent = 0;
        if (avgPrice > 0) {
          diffPercent = ((lastPrice - avgPrice) / avgPrice) * 100;
        }

        statsArray.push({
          id: p.id,
          name: p.name,
          avgPrice,
          lastPrice,
          diffPercent
        });
      }
    });

    return statsArray.sort((a, b) => b.diffPercent - a.diffPercent);
  }, [products, purchases]);

  const filteredPriceStats = useMemo(() => {
    return priceStats.filter(stat => {
      const matchesSearch = stat.name.toLowerCase().includes(priceSearchTerm.toLowerCase());
      const matchesTrend = 
        priceTrendFilter === 'all' ? true :
        priceTrendFilter === 'increase' ? stat.diffPercent > 0 :
        priceTrendFilter === 'decrease' ? stat.diffPercent < 0 : true;
      return matchesSearch && matchesTrend;
    });
  }, [priceStats, priceSearchTerm, priceTrendFilter]);

  const anomalies = useMemo(() => {
    const alerts: Array<{ id: string; type: 'warning' | 'critical' | 'info'; title: string; desc: string; icon: any }> = [];

    const getGrossQuantity = (netQuantity: number, lossPercentage: number = 0): number => {
      const validLoss = Math.min(Math.max(lossPercentage, 0), 99);
      return netQuantity / (1 - (validLoss / 100));
    };

    const balances: Record<string, number> = {};
    const consumedMap: Record<string, number> = {};
    products.forEach(p => { balances[p.id] = 0; consumedMap[p.id] = 0; });
    
    purchases.forEach(p => { balances[p.productId] += p.quantity; });
    
    sales.forEach(s => {
      const dish = dishes.find(d => d.id === s.dishId);
      if (dish) {
        dish.ingredients.forEach(ing => {
          const grossQty = getGrossQuantity(ing.quantity, ing.lossPercentage || 0);
          balances[ing.productId] -= (grossQty * s.quantity);
          consumedMap[ing.productId] += (grossQty * s.quantity);
        });
      }
    });

    const firstPurchaseDate = purchases.length > 0 
      ? new Date(Math.min(...purchases.map(p => new Date(p.date).getTime()))) 
      : new Date();
    const daysSinceFirst = Math.max(30, (new Date().getTime() - firstPurchaseDate.getTime()) / (1000 * 3600 * 24));

    if (inventoryAudits.length > 0) {
      const sortedAudits = [...inventoryAudits].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      const latestAudit = sortedAudits[0];
      const prevAudit = sortedAudits[1] || null;

      products.forEach(p => {
        const startingBal = prevAudit && prevAudit.balances[p.id] !== undefined ? prevAudit.balances[p.id] : 0;
        
        const windowPurchases = purchases.filter(pur => pur.productId === p.id && pur.date <= latestAudit.date && (!prevAudit || pur.date > prevAudit.date));
        const purchased = windowPurchases.reduce((sum, pur) => sum + pur.quantity, 0);

        let consumed = 0;
        const windowSales = sales.filter(s => s.date <= latestAudit.date && (!prevAudit || s.date > prevAudit.date));
        windowSales.forEach(s => {
          const dish = dishes.find(d => d.id === s.dishId);
          if (dish) {
            const ing = dish.ingredients.find(i => i.productId === p.id);
            if (ing) {
              consumed += getGrossQuantity(ing.quantity, ing.lossPercentage) * s.quantity;
            }
          }
        });

        const expected = startingBal + purchased - consumed;
        const actual = latestAudit.balances[p.id];

        if (actual !== undefined && expected > 0) {
          const missing = expected - actual;
          const percentMissing = (missing / expected) * 100;
          
          // Anomaly Detection: Actual Stock - Expected Stock > 5% variance
          if (missing > 5 && percentMissing > 5) {
            alerts.push({
              id: `shrinkage-${p.id}`,
              type: 'critical',
              title: t(language, 'shrinkageTitle'),
              desc: t(language, 'shrinkageDesc', { 
                product: p.name, 
                actual: actual.toFixed(2), 
                expected: expected.toFixed(2), 
                missing: missing.toFixed(2) 
              }),
              icon: SearchX
            });
          }
        }
      });
    }

    products.forEach(p => {
      const pPurchases = purchases
        .filter(pur => pur.productId === p.id)
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      const len = pPurchases.length;
      
      if (len >= 2) {
        const lastPrice = pPurchases[len - 1].price;
        const prevPrice = pPurchases[len - 2].price;
        // Adjusted Price Audit threshold: strictly > 10%
        if (prevPrice > 0 && lastPrice > prevPrice * 1.10) {
          const percentIncrease = (((lastPrice - prevPrice) / prevPrice) * 100).toFixed(1);
          alerts.push({
            id: `jump-${p.id}`,
            type: 'critical',
            title: `${p.name} - ${t(language, 'priceJumpTitle')}`,
            desc: t(language, 'priceJumpDesc', { percent: percentIncrease, prev: formatCurrency(prevPrice), curr: formatCurrency(lastPrice) }),
            icon: AlertCircle
          });
        }
      }

      if (len >= 3) {
        const oldestOfLastThreePrice = pPurchases[len - 3].price;
        const newestPrice = pPurchases[len - 1].price;
        if (oldestOfLastThreePrice > 0 && newestPrice > oldestOfLastThreePrice * 1.10) {
           const percentIncrease = (((newestPrice - oldestOfLastThreePrice) / oldestOfLastThreePrice) * 100).toFixed(1);
           alerts.push({
            id: `inflation-${p.id}`,
            type: 'warning',
            title: t(language, 'supplierRecommendation'),
            desc: t(language, 'inflationAlertDesc', { percent: percentIncrease, product: p.name }),
            icon: Users
          });
        }
      }

      const currentStock = balances[p.id] || 0;
      const totalConsumed = consumedMap[p.id] || 0;
      
      if (currentStock >= 5 && totalConsumed === 0) {
        alerts.push({
          id: `dead-${p.id}`,
          type: 'info',
          title: `${p.name} - ${t(language, 'deadStockTitle')}`,
          desc: t(language, 'deadStockDesc', { qty: currentStock.toFixed(2) }),
          icon: PackageOpen
        });
      } else if (totalConsumed > 0) {
        const dailyConsumption = totalConsumed / daysSinceFirst;
        if (currentStock > (dailyConsumption * 90) && currentStock > 10) {
          alerts.push({
            id: `overstock-${p.id}`,
            type: 'warning',
            title: t(language, 'overstockTitle'),
            desc: t(language, 'overstockDesc', { product: p.name, stock: currentStock.toFixed(2) }),
            icon: ArchiveX
          });
        }
      }
    });

    dishes.forEach(dish => {
      dish.ingredients.forEach(ing => {
        const prod = products.find(p => p.id === ing.productId);
        if (prod && (prod.unit === 'piece' || prod.unit === 'pack') && ing.quantity < 0.25) {
          if (!alerts.some(a => a.id === `mismatch-${prod.id}`)) {
             alerts.push({
                id: `mismatch-${prod.id}`,
                type: 'warning',
                title: t(language, 'mismatchTitle'),
                desc: t(language, 'mismatchDesc', { product: prod.name, unit: t(language, `unit_${prod.unit}`) || prod.unit, qty: ing.quantity }),
                icon: Scale
             });
          }
        }
      });
    });

    return alerts;
  }, [products, purchases, sales, dishes, inventoryAudits, language]);

  const filteredAnomalies = useMemo(() => {
    if (anomalyTypeFilter === 'all') return anomalies;
    return anomalies.filter(a => a.type === anomalyTypeFilter);
  }, [anomalies, anomalyTypeFilter]);

  // EXPORT FUNCTIONS
  const handleExportPrices = () => {
    const dataToExport = filteredPriceStats.map(stat => ({
      [t(language, 'productName')]: stat.name,
      [t(language, 'avgPrice')]: Number(stat.avgPrice.toFixed(2)),
      [t(language, 'lastPrice')]: Number(stat.lastPrice.toFixed(2)),
      [t(language, 'trend')]: `${stat.diffPercent > 0 ? '+' : ''}${stat.diffPercent.toFixed(1)}%`
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, t(language, 'priceGainersLosers').substring(0, 31));
    XLSX.writeFile(workbook, `Price_Trends_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const handleExportAnomalies = () => {
    const dataToExport = filteredAnomalies.map(anomaly => ({
      [t(language, 'severity')]: t(language, `filter${anomaly.type.charAt(0).toUpperCase() + anomaly.type.slice(1)}`),
      [t(language, 'productName')]: anomaly.title,
      [t(language, 'description')]: anomaly.desc
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataToExport);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, t(language, 'auditAnomalies').substring(0, 31));
    XLSX.writeFile(workbook, `Audit_Anomalies_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  return (
    <div className="p-4 sm:p-6 max-w-[1400px] mx-auto w-full space-y-6">
      
      {/* Header */}
      <div className="flex items-center space-x-3 mb-6">
        <div className="bg-indigo-100 p-2.5 rounded-xl">
          <BrainCircuit className="w-6 h-6 text-indigo-600" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">{t(language, 'aiInsights')}</h2>
          <p className="text-sm text-gray-500 mt-0.5">{t(language, 'aiInsightsDesc')}</p>
        </div>
      </div>

      <div className="flex flex-col space-y-8">

        {/* Section 0: Period Comparisons */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 flex flex-col">
          <div className="p-5 border-b border-gray-100 bg-gray-50/50 flex items-center shrink-0">
            <CalendarRange className="w-5 h-5 text-gray-500 mr-2" />
            <h3 className="text-lg font-bold text-gray-900">
              {language === 'ka' ? 'პერიოდების შედარება' : 'Period Comparisons'}
            </h3>
          </div>

          <div className="p-5 space-y-4">
            {/* Quick presets */}
            <div className="flex flex-wrap gap-2">
              {presets.map(p => (
                <button
                  key={p.label}
                  onClick={() => applyPreset(p.a, p.b)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors"
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Manual period pickers */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="border border-slate-200 rounded-xl p-3">
                <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400 mb-2">
                  {language === 'ka' ? 'პერიოდი A' : 'Period A'}
                </p>
                <div className="flex items-center gap-2">
                  <input type="date" value={periodAFrom} max={periodATo}
                    onChange={(e) => setPeriodAFrom(e.target.value)}
                    className="flex-1 min-w-0 px-2 py-1.5 border border-slate-300 rounded-lg text-xs" />
                  <span className="text-slate-400 text-xs">—</span>
                  <input type="date" value={periodATo} min={periodAFrom}
                    onChange={(e) => setPeriodATo(e.target.value)}
                    className="flex-1 min-w-0 px-2 py-1.5 border border-slate-300 rounded-lg text-xs" />
                </div>
              </div>
              <div className="border border-slate-200 rounded-xl p-3">
                <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400 mb-2">
                  {language === 'ka' ? 'პერიოდი B (შედარებისთვის)' : 'Period B (comparison)'}
                </p>
                <div className="flex items-center gap-2">
                  <input type="date" value={periodBFrom} max={periodBTo}
                    onChange={(e) => setPeriodBFrom(e.target.value)}
                    className="flex-1 min-w-0 px-2 py-1.5 border border-slate-300 rounded-lg text-xs" />
                  <span className="text-slate-400 text-xs">—</span>
                  <input type="date" value={periodBTo} min={periodBFrom}
                    onChange={(e) => setPeriodBTo(e.target.value)}
                    className="flex-1 min-w-0 px-2 py-1.5 border border-slate-300 rounded-lg text-xs" />
                </div>
              </div>
            </div>
          </div>

          <div className="px-5 pb-5 grid grid-cols-1 md:grid-cols-2 gap-4">
            {(() => {
              const diff = selectedComparison.purchases.diff;
              const up = diff > 0.05;
              const down = diff < -0.05;
              const badgeClass = up ? 'bg-red-100 text-red-700' : down ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600';
              const drivers = periodDetailsOpen ? getPeriodDrivers(selectedComparison.currentRange, selectedComparison.previousRange) : [];

              return (
                <div className="border border-slate-200 rounded-2xl p-5 bg-white">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <h4 className="text-sm font-bold text-slate-800">
                        {language === 'ka' ? 'შესყიდვების შედარება' : 'Purchases Comparison'}
                      </h4>
                      <p className="text-xs text-slate-500 mt-1">
                        {periodAFrom} → {periodATo} <span className="mx-1 text-slate-300">vs</span> {periodBFrom} → {periodBTo}
                      </p>
                    </div>
                    <div className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-full text-xs font-bold shrink-0 ${badgeClass}`}>
                      {up && <TrendingUp className="w-3.5 h-3.5" />}
                      {down && <TrendingDown className="w-3.5 h-3.5" />}
                      {!up && !down && <Minus className="w-3.5 h-3.5" />}
                      {diff > 0 ? '+' : ''}{diff.toFixed(1)}%
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div>
                      <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
                        {language === 'ka' ? 'პერიოდი A' : 'Period A'}
                      </p>
                      <p className="text-2xl font-black text-slate-900 mt-1 leading-tight">
                        {formatCurrency(selectedComparison.purchases.current)}
                      </p>
                    </div>
                    <div>
                      <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
                        {language === 'ka' ? 'პერიოდი B' : 'Period B'}
                      </p>
                      <p className="text-2xl font-black text-slate-500 mt-1 leading-tight">
                        {formatCurrency(selectedComparison.purchases.previous)}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setPeriodDetailsOpen(!periodDetailsOpen)}
                    className="mt-4 text-xs font-semibold text-brand-600 hover:text-brand-700 flex items-center gap-1"
                  >
                    {periodDetailsOpen
                      ? (language === 'ka' ? 'დეტალების დამალვა ▲' : 'Hide details ▲')
                      : (language === 'ka' ? 'რამ გამოიწვია ცვლილება? ▾' : 'What drove the change? ▾')}
                  </button>

                  {periodDetailsOpen && (
                    drivers.length === 0 ? (
                      <p className="text-xs text-slate-400 mt-3">
                        {language === 'ka' ? 'ამ პერიოდში მონაცემი არ არის' : 'No data for this period'}
                      </p>
                    ) : (
                      <div className="mt-3 pt-3 border-t border-slate-100 space-y-1.5">
                        {drivers.map(d => {
                          const dUp = d.delta > 0;
                          return (
                            <div key={d.productId} className="flex items-center justify-between text-xs gap-2">
                              <span className="text-slate-600 truncate min-w-0">{d.name}</span>
                              <span className={`font-bold shrink-0 ${dUp ? 'text-red-600' : d.delta < 0 ? 'text-green-600' : 'text-slate-400'}`}>
                                {dUp ? '+' : ''}{formatCurrency(d.delta)}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    )
                  )}
                </div>
              );
            })()}

            <div className="border border-brand-200 rounded-2xl p-5 bg-brand-50/30 flex flex-col">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="w-4 h-4 text-brand-600 shrink-0" />
                <h4 className="text-sm font-bold text-slate-800">
                  {language === 'ka' ? 'ჰკითხე AI ანალიტიკოსს' : 'Ask AI Analyst'}
                  <span className="ml-1.5 text-[10px] font-normal text-slate-400">
                    {language === 'ka' ? '(საჭიროებს API credit-ს)' : '(uses API credit)'}
                  </span>
                </h4>
              </div>

              <textarea
                value={insightQuestion}
                onChange={(e) => setInsightQuestion(e.target.value)}
                placeholder={language === 'ka'
                  ? 'მაგ: რისგან არის გამოწვეული ამხელა ცვლილება სეზონურობის შედარებისას?'
                  : 'e.g. What caused such a big change in the seasonal comparison?'}
                rows={2}
                className="w-full text-xs border border-slate-200 rounded-lg px-3 py-2 resize-none focus:ring-2 focus:ring-brand-400 focus:border-brand-400 bg-white placeholder:text-slate-400"
              />

              <button
                onClick={handleAskInsight}
                disabled={insightLoading || !insightQuestion.trim()}
                className="mt-2 inline-flex items-center justify-center gap-1.5 bg-brand-600 text-white rounded-lg px-3 py-1.5 text-xs font-bold hover:bg-brand-700 disabled:bg-gray-300 disabled:cursor-not-allowed self-start"
              >
                {insightLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <MessageCircleQuestion className="w-3.5 h-3.5" />}
                {insightLoading ? (language === 'ka' ? 'ანალიზი...' : 'Analyzing...') : (language === 'ka' ? 'კითხვა' : 'Ask')}
              </button>

              {insightError && (
                <p className="text-xs text-red-600 mt-3">⚠️ {insightError}</p>
              )}

              {insightAnswer && (
                <div className="mt-3 pt-3 border-t border-brand-200/60">
                  <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">{insightAnswer}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Section 1: Price Trends Chart (Full Width) */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 flex flex-col h-[450px]">
          <div className="p-5 border-b border-gray-100 bg-gray-50/50 flex items-center shrink-0">
            <LineChartIcon className="w-5 h-5 text-gray-500 mr-2" />
            <h3 className="text-lg font-bold text-gray-900">{t(language, 'priceAnalysis')}</h3>
          </div>
          
          <div className="p-6 flex-1 flex flex-col min-h-0">
            <h4 className="text-sm font-semibold text-gray-700 mb-4 text-center">{t(language, 'topProductsChart')}</h4>
            
            {priceChartDataAndLines.lines.length === 0 ? (
              <div className="flex-1 flex items-center justify-center border-2 border-dashed border-gray-200 rounded-xl">
                <p className="text-gray-400 font-medium">{t(language, 'noChartData')}</p>
              </div>
            ) : (
              <div className="flex-1 w-full min-h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={priceChartDataAndLines.data} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                    <XAxis 
                      dataKey="date" 
                      tick={{ fill: '#64748b', fontSize: 12 }} 
                      axisLine={false} 
                      tickLine={false}
                      dy={10}
                    />
                    <YAxis 
                      tick={{ fill: '#64748b', fontSize: 12 }} 
                      axisLine={false} 
                      tickLine={false} 
                      tickFormatter={(val) => formatCurrency(val)}
                    />
                    <Tooltip 
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                      labelStyle={{ fontWeight: 'bold', color: '#0f172a', marginBottom: '8px' }}
                    />
                    <Legend wrapperStyle={{ paddingTop: '10px', fontSize: '12px', fontWeight: 500 }} />
                    
                    {priceChartDataAndLines.lines.map((lineName, idx) => (
                      <Line 
                        key={lineName}
                        type="monotone" 
                        dataKey={lineName} 
                        stroke={CHART_COLORS[idx % CHART_COLORS.length]} 
                        strokeWidth={3}
                        dot={{ r: 4, strokeWidth: 2 }}
                        activeDot={{ r: 6 }}
                        connectNulls={true}
                      />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        </div>

        {/* Section 2: Price Gainers & Losers Smart Table (Full Width) */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 flex flex-col">
          <div className="p-5 border-b border-gray-100 bg-gray-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center">
              <TrendingUp className="w-5 h-5 text-gray-500 mr-2" />
              <h3 className="text-lg font-bold text-gray-900">{t(language, 'priceGainersLosers')}</h3>
            </div>
            <div className="flex flex-wrap items-center w-full sm:w-auto gap-3">
              <div className="relative flex-grow sm:flex-none">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder={t(language, 'search')}
                  value={priceSearchTerm}
                  onChange={(e) => setPriceSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-brand-500 focus:border-brand-500 transition-shadow"
                />
              </div>
              <div className="relative flex-grow sm:flex-none">
                <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <select
                  value={priceTrendFilter}
                  onChange={(e) => setPriceTrendFilter(e.target.value as any)}
                  className="w-full pl-9 pr-8 py-2 border border-gray-300 rounded-lg text-sm focus:ring-brand-500 focus:border-brand-500 bg-white appearance-none cursor-pointer"
                >
                  <option value="all">{t(language, 'filterAll')}</option>
                  <option value="increase">{t(language, 'filterIncreased')}</option>
                  <option value="decrease">{t(language, 'filterDecreased')}</option>
                </select>
              </div>
              <button
                onClick={handleExportPrices}
                className="flex items-center justify-center px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors shadow-sm w-full sm:w-auto"
              >
                <Download className="w-4 h-4 mr-2" />
                {t(language, 'exportExcel')}
              </button>
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-white">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">{t(language, 'productName')}</th>
                  <th className="px-6 py-4 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">{t(language, 'avgPrice')}</th>
                  <th className="px-6 py-4 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">{t(language, 'lastPrice')}</th>
                  <th className="px-6 py-4 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">{t(language, 'trend')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 bg-white">
                {filteredPriceStats.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-8 text-center text-sm text-gray-500">
                      {t(language, 'noChartData')}
                    </td>
                  </tr>
                ) : (
                  filteredPriceStats.map((stat) => {
                    const isCostIncrease = stat.diffPercent > 0;
                    const isCostDecrease = stat.diffPercent < 0;
                    const isExpanded = expandedPriceProductId === stat.id;
                    const history = isExpanded
                      ? purchases
                          .filter(p => p.productId === stat.id)
                          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      : [];

                    return (
                      <React.Fragment key={stat.id}>
                        <tr
                          onClick={() => handlePriceRowClick(stat.id)}
                          className={`cursor-pointer transition-colors ${isExpanded ? 'bg-brand-50/60' : 'hover:bg-slate-50'}`}
                          title={isExpanded
                            ? (language === 'ka' ? 'კიდევ ერთხელ დააწექი — ამ პროდუქტის შესყიდვებზე გადასვლა' : 'Click again to open this product\'s purchases')
                            : (language === 'ka' ? 'დააწექი ფასების ისტორიის სანახავად' : 'Click to view price history')}
                        >
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{stat.name}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 text-right">{formatCurrency(stat.avgPrice)}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900 text-right">{formatCurrency(stat.lastPrice)}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-right">
                            <div className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold ${isCostIncrease ? 'bg-red-100 text-red-700' : isCostDecrease ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                              {isCostIncrease && <TrendingUp className="w-3.5 h-3.5 mr-1" />}
                              {isCostDecrease && <TrendingDown className="w-3.5 h-3.5 mr-1" />}
                              {!isCostIncrease && !isCostDecrease && <span className="mr-1">-</span>}
                              {Math.abs(stat.diffPercent).toFixed(1)}%
                            </div>
                          </td>
                        </tr>
                        {isExpanded && (
                          <tr className="bg-slate-50/70">
                            <td colSpan={4} className="px-6 py-4">
                              <div className="text-xs font-bold text-slate-600 mb-2 flex items-center justify-between">
                                <span>{language === 'ka' ? 'ფასების ისტორია' : 'Price history'} ({history.length})</span>
                                <span className="text-slate-400 font-normal">
                                  {language === 'ka' ? 'კიდევ ერთხელ დააწექი სტრიქონს → ამ პროდუქტის შესყიდვები' : 'Click row again → product purchases'}
                                </span>
                              </div>
                              {history.length === 0 ? (
                                <div className="text-sm text-slate-500">{t(language, 'noChartData')}</div>
                              ) : (
                                <div className="max-h-72 overflow-y-auto rounded border border-slate-200 bg-white">
                                  <table className="min-w-full text-xs">
                                    <thead className="bg-slate-100 text-slate-600 sticky top-0">
                                      <tr>
                                        <th className="px-3 py-2 text-left font-semibold">{t(language, 'date') || (language === 'ka' ? 'თარიღი' : 'Date')}</th>
                                        <th className="px-3 py-2 text-right font-semibold">{t(language, 'price')}</th>
                                        <th className="px-3 py-2 text-right font-semibold">{t(language, 'quantity')}</th>
                                        <th className="px-3 py-2 text-right font-semibold">{language === 'ka' ? 'ცვლილება' : 'Change'}</th>
                                      </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100">
                                      {history.map((p, idx) => {
                                        const prev = history[idx + 1];
                                        const diff = prev && prev.price > 0 ? ((p.price - prev.price) / prev.price) * 100 : 0;
                                        const up = diff > 0.01, down = diff < -0.01;
                                        return (
                                          <tr key={p.id} className="hover:bg-slate-50">
                                            <td className="px-3 py-1.5 text-slate-700 font-mono">{p.date}</td>
                                            <td className="px-3 py-1.5 text-right font-semibold text-slate-900">{formatCurrency(p.price)}</td>
                                            <td className="px-3 py-1.5 text-right text-slate-600">{p.quantity}</td>
                                            <td className={`px-3 py-1.5 text-right font-semibold ${up ? 'text-red-600' : down ? 'text-green-600' : 'text-slate-400'}`}>
                                              {prev ? `${up ? '+' : ''}${diff.toFixed(1)}%` : '—'}
                                            </td>
                                          </tr>
                                        );
                                      })}
                                    </tbody>
                                  </table>
                                </div>
                              )}
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })

                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 3: Audit & Anomalies (Full Width with Grid Cards) */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden flex flex-col">
          <div className="p-5 border-b border-gray-100 bg-gray-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center">
              <ShieldAlert className="w-5 h-5 text-gray-500 mr-2" />
              <h3 className="text-lg font-bold text-gray-900">{t(language, 'auditAnomalies')}</h3>
            </div>
            <div className="flex flex-wrap items-center w-full sm:w-auto gap-3">
              <div className="relative flex-grow sm:flex-none">
                <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <select
                  value={anomalyTypeFilter}
                  onChange={(e) => setAnomalyTypeFilter(e.target.value as any)}
                  className="w-full pl-9 pr-8 py-2 border border-gray-300 rounded-lg text-sm focus:ring-brand-500 focus:border-brand-500 bg-white appearance-none cursor-pointer"
                >
                  <option value="all">{t(language, 'filterAll')}</option>
                  <option value="critical">{t(language, 'filterCritical')}</option>
                  <option value="warning">{t(language, 'filterWarning')}</option>
                  <option value="info">{t(language, 'filterInfo')}</option>
                </select>
              </div>
              <button
                onClick={handleExportAnomalies}
                className="flex items-center justify-center px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors shadow-sm w-full sm:w-auto"
              >
                <Download className="w-4 h-4 mr-2" />
                {t(language, 'exportExcel')}
              </button>
            </div>
          </div>
          
          <div className="p-6 bg-slate-50/30">
            {filteredAnomalies.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12">
                <div className="bg-green-50 p-4 rounded-full mb-4">
                  <CheckCircle className="w-10 h-10 text-green-400" />
                </div>
                <p className="text-gray-500 font-medium">{t(language, 'noAnomalies')}</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                {filteredAnomalies.map((anomaly) => {
                  const Icon = anomaly.icon;
                  const isCritical = anomaly.type === 'critical';
                  const isWarning = anomaly.type === 'warning';
                  
                  return (
                    <div 
                      key={anomaly.id} 
                      className={`flex flex-col p-4 rounded-xl border ${isCritical ? 'bg-red-50 border-red-200 shadow-sm' : isWarning ? 'bg-amber-50 border-amber-200 shadow-sm' : 'bg-white border-slate-200 shadow-sm'}`}
                    >
                      <div className="flex items-start mb-3">
                        <div className={`p-2 rounded-lg shrink-0 mr-3 ${isCritical ? 'bg-red-100' : isWarning ? 'bg-amber-100' : 'bg-slate-100'}`}>
                          <Icon className={`w-5 h-5 ${isCritical ? 'text-red-600' : isWarning ? 'text-amber-600' : 'text-slate-600'}`} />
                        </div>
                        <h4 className={`text-sm font-bold uppercase tracking-wide mt-1 ${isCritical ? 'text-red-900' : isWarning ? 'text-amber-900' : 'text-slate-900'}`}>
                          {anomaly.title}
                        </h4>
                      </div>
                      <p className={`text-sm leading-relaxed flex-1 ${isCritical ? 'text-red-800' : isWarning ? 'text-amber-800' : 'text-slate-600'}`}>
                        {anomaly.desc}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
import { Department } from '../types';

export type ExtDepartment = Department | 'other';

interface ClassifyRule {
  readonly keywords: readonly string[];
  readonly dept: ExtDepartment;
}

const RULES: readonly ClassifyRule[] = [
  {
    keywords: ['ავტო', 'ნაწილი', 'ძრავა', 'ძრითადი საშუალება', 'ავეჯი',
               'საკანცელარიო', 'ტექნიკა', 'ელექტრო', 'სარემონტო',
               'ფიცარი', 'მილი', 'ცემენტი', 'ლენტი', 'სენდვიჩ',
               'ლითონი', 'ხელსაწყო', 'კომპლექტი', 'ნაკრები',
               'კვ.მ', 'მეტრი', 'ტონა', 'ბალონი', 'ბლოკი'],
    dept: 'other',
  },
  {
    keywords: ['ჩუსტი', 'ტილო', 'სარეცხი', 'საპონი', 'შხაპი',
               'ნომრის სახარჯი', 'სახარჯი მასალა', 'მცირეფასიანი',
               'ბაჭია', 'ჭიქა ქაღალდი', 'ჭიქა', 'საწრუპი',
               'ნაგვის', 'ჩანგალი ლუქსი', 'ლუქსი', 'სასტუმრო'],
    dept: 'housekeeping',
  },
  {
    keywords: ['ღვინო', 'ლუდი', 'არაყი', 'ვისკი', 'ჯინი', 'რომი',
               'ტეკილა', 'ლიქიორი', 'ვერმუტი', 'კოკა', 'სპრაიტი',
               'ფანტა', 'ლიმონათი', 'ბორჯომი', 'ნაბეღლავი', 'წყალი',
               'ყავა', 'ჩაი', 'სიროფი', 'ენერგეტიკ', 'კეგი', 'შამპანური',
               'ცქრიალა', 'ბრენდი', 'შნაპსი', 'რედბული', 'Red Bull'],
    dept: 'bar',
  },
  {
    keywords: ['ბოსტნეული', 'ხილი', 'ხორცი', 'ქათამი', 'თევზი',
               'ყველი', 'პური', 'კვერცხი', 'ზეთი', 'სუნელი',
               'ბრინჯი', 'მარცვლეული', 'ჯემი', 'მაკარონი', 'პასტა',
               'სოუსი', 'მდოგვი', 'კეჩუპი', 'მაიონეზი', 'ნაღები',
               'არაჟანი', 'მაწონი', 'ნადუღი', 'ხაჭო', 'რძე',
               'კარტოფილი', 'პომიდორი', 'კიტრი', 'ხახვი', 'ნიორი',
               'სტაფილო', 'ბადრიჯანი', 'ყაბაყი', 'ბოსტ', 'სოკო',
               'ლობიო', 'ბარდა', 'სიმინდი', 'ქინძი', 'ოხრახუში',
               'ბანანი', 'ვაშლი', 'ფორთოხალი', 'ლიმონი', 'მსხალი',
               'ყურძენი', 'ბროწეული', 'ზეითუნი', 'თაფლი', 'შაქარი',
               'ფქვილი', 'საფუარი', 'ძმარი', 'მარილი', 'პილპილი',
               'კალმახი', 'ორაგული', 'კრევეტი', 'ნიუ', 'ტყემალი',
               'სამზარეულო'],
    dept: 'restaurant',
  },
] as const;

export function classifyRow(
  classShort: string,
  deptRaw: string,
  productName: string,
): ExtDepartment | 'unmatched' {
  if (deptRaw === 'ბარი') return 'bar';
  if (deptRaw === 'სამზარეულო') return 'restaurant';

  const haystack = `${classShort} ${productName}`.toLowerCase();

  for (const rule of RULES) {
    if (rule.keywords.some(kw => haystack.includes(kw.toLowerCase()))) {
      return rule.dept;
    }
  }

  return 'unmatched';
}

export const DEPT_LABELS: Record<ExtDepartment | 'unmatched', string> = {
  restaurant:   'სამზარეულო',
  bar:          'ბარი',
  breakfast:    'საუზმე',
  housekeeping: 'ჰაუსქიფინგი',
  technical:    'ტექნიკური',
  other:        'სხვა (არ ატვირთება)',
  unmatched:    'უცნობი',
};

import * as XLSX from 'xlsx';
import { Product, Department } from '../types';

// ====== UNIT NORMALIZATION ======

export function normalizeUnit(raw: string): string {
  const u = (raw || '').trim();
  if (u === 'კგ' || u === 'კილოგრამი' || u === 'კილოგრამი- KG') return 'კგ';
  if (u === 'ცალი' || u === 'ც' || u === 'ცალი - ADET') return 'ც';
  if (u === 'ლიტრი' || u === 'ლ' || u === 'ლიტრა') return 'ლ';
  return u;
}

export function normalizeIngredientUnit(rawUnit: string, quantity: number): { unit: string; quantity: number } {
  const u = (rawUnit || '').trim();
  if (u === 'გრ') return { unit: 'კგ', quantity: quantity / 1000 };
  if (u === 'მმ') return { unit: 'ლ', quantity };
  if (u === 'ქ') return { unit: 'ც', quantity };
  return { unit: normalizeUnit(u), quantity };
}

function mapDepartment(raw: string): Department {
  const r = (raw || '').trim();
  if (r === 'ბარი') return 'bar';
  return 'restaurant';
}

function excelSerialToDateStr(serial: number): string {
  const ms = Math.round((serial - 25569) * 86400 * 1000);
  const d = new Date(ms);
  if (isNaN(d.getTime())) return '';
  return d.toISOString().substring(0, 10);
}

function coerceDate(val: any): string {
  if (!val) return '';
  if (val instanceof Date) return val.toISOString().substring(0, 10);
  if (typeof val === 'number') return excelSerialToDateStr(val);
  const s = String(val).trim();
  // already ISO-like
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.substring(0, 10);
  const d = new Date(s);
  return isNaN(d.getTime()) ? '' : d.toISOString().substring(0, 10);
}

// ====== PURCHASES IMPORT ======

export interface ParsedPurchase {
  date: string;
  productName: string;
  category: string;
  unit: string;
  quantity: number;
  price: number;
  total: number;
  department: Department;
  supplier?: string;
}

export async function parsePurchaseFile(file: File): Promise<ParsedPurchase[]> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: 'array', cellDates: true });
  // Prefer "შესყიდვა" sheet if present
  const sheetName = wb.SheetNames.find(n => n.includes('შესყიდ')) || wb.SheetNames[0];
  const ws = wb.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null }) as any[][];

  const result: ParsedPurchase[] = [];
  for (let i = 2; i < rows.length; i++) {
    const row = rows[i];
    if (!row) continue;
    if (!row[1] || !row[8]) continue;

    const dateStr = coerceDate(row[1]);
    if (!dateStr) continue;

    const unitRaw = String(row[16] ?? '').trim();
    const unit = normalizeUnit(unitRaw);
    const qty = parseFloat(row[17]) || 0;
    const price = parseFloat(row[18]) || 0;
    if (qty <= 0 || price <= 0) continue;

    const supplierRaw = String(row[6] ?? '').trim();

    result.push({
      date: dateStr,
      productName: String(row[8] ?? '').replace(/^"|"$/g, '').trim(),
      category: String(row[9] ?? '').trim(),
      unit,
      quantity: qty,
      price,
      total: parseFloat(row[19]) || qty * price,
      department: mapDepartment(String(row[13] ?? '')),
      supplier: supplierRaw || undefined,
    });
  }
  return result;
}

// ====== BOM / KALKULACI IMPORT ======

export interface ParsedIngredient {
  code: string;
  name: string;
  unit: string;
  quantity: number;
  matchedProductId: string | null;
  isNew: boolean;
  lastPrice: number | null;
}

export interface ParsedDish {
  code: string;
  name: string;
  category: string;
  ingredients: ParsedIngredient[];
}

export interface ParsedBOMResult {
  dishes: ParsedDish[];
  newProducts: Product[];
}

const generateId = () => Math.random().toString(36).substring(2, 11);

export async function parseKalkulaciFile(
  file: File,
  existingProducts: Product[],
  purchases: { productId: string; price: number; date: string }[],
): Promise<ParsedBOMResult> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: 'array' });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null }) as any[][];

  // Build lookup for last purchase price per productId
  const lastPriceByProduct = new Map<string, number>();
  const sortedPurchases = [...purchases].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  for (const p of sortedPurchases) {
    if (!lastPriceByProduct.has(p.productId)) lastPriceByProduct.set(p.productId, p.price);
  }

  // Track newly-created products to ensure same ingredient across dishes reuses one Product
  const newProductsByKey = new Map<string, Product>();

  const findOrCreate = (code: string, name: string, unit: string): { product: Product; isNew: boolean } => {
    const codeTrim = (code || '').trim();
    if (codeTrim) {
      const byCode = existingProducts.find(p => p.code === codeTrim);
      if (byCode) return { product: byCode, isNew: false };
    }
    const nameLower = name.trim().toLowerCase();
    const byName = existingProducts.find(p => p.name.trim().toLowerCase() === nameLower);
    if (byName) return { product: byName, isNew: false };

    const key = codeTrim || nameLower;
    const existingNew = newProductsByKey.get(key);
    if (existingNew) return { product: existingNew, isNew: true };

    const np: Product = {
      id: generateId(),
      code: codeTrim || undefined,
      name: name.trim(),
      unit,
      category: 'ნედლეული',
      minBalance: 0,
      department: 'restaurant',
    };
    newProductsByKey.set(key, np);
    return { product: np, isNew: true };
  };

  const dishes: ParsedDish[] = [];
  let current: ParsedDish | null = null;

  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row) continue;
    const rowType = String(row[0] ?? '').trim();

    if (rowType === 'კერძი') {
      if (current) dishes.push(current);
      current = {
        code: String(row[1] ?? '').trim(),
        name: String(row[2] ?? '').trim(),
        category: String(row[8] ?? '').trim(),
        ingredients: [],
      };
    } else if (rowType === 'ინგრედიენტი' && current) {
      const ingrCode = String(row[1] ?? '').trim();
      const ingrName = String(row[2] ?? '').trim();
      if (!ingrName) continue;
      const unitRaw = String(row[3] ?? '').trim();
      const qtyRaw = parseFloat(row[4]) || 0;
      const { unit, quantity } = normalizeIngredientUnit(unitRaw, qtyRaw);
      const { product, isNew } = findOrCreate(ingrCode, ingrName, unit);

      current.ingredients.push({
        code: ingrCode,
        name: ingrName,
        unit,
        quantity,
        matchedProductId: product.id,
        isNew,
        lastPrice: lastPriceByProduct.get(product.id) ?? null,
      });
    }
  }
  if (current) dishes.push(current);

  return { dishes, newProducts: Array.from(newProductsByKey.values()) };
}


// ====== SALES IMPORT (detailed POS export) ======

export interface ParsedSaleRow {
  date: string;
  rawName: string;
  dishId: string | null;
  dishName: string | null;
  quantity: number;
  department?: Department;
}

function extractDishName(raw: string): string {
  const m = raw.match(/^[\u10A0-\u10FF0-9\s.,:;"'()\-/%]+/);
  let s = (m ? m[0] : raw).trim();
  s = s.replace(/["'.:\-/\s]+$/, '').trim();
  return s;
}

function stripTrailingVolume(s: string): string {
  return s.replace(/\s+[\d.,]+\s*(ლ|მლ|კგ|გრ|წ)\.?$/, '').trim();
}

function matchDishByName(
  rawName: string,
  dishByLowerName: Map<string, { id: string; name: string; department?: Department }>,
): { id: string | null; name: string | null; department?: Department } {
  const ext = extractDishName(rawName);
  const candidates = [ext, stripTrailingVolume(ext)];
  candidates.push(stripTrailingVolume(candidates[1]));
  for (const cand of candidates) {
    const hit = dishByLowerName.get(cand.toLowerCase());
    if (hit) return { id: hit.id, name: hit.name, department: hit.department };
  }
  return { id: null, name: null };
}

export async function parseSalesFile(
  file: File,
  dishes: { id: string; name: string; department?: Department }[],
): Promise<ParsedSaleRow[]> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: 'array', cellDates: true });
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null }) as any[][];

  const dishByLowerName = new Map<string, { id: string; name: string; department?: Department }>();
  dishes.forEach(d => dishByLowerName.set(d.name.trim().toLowerCase(), d));

  // aggregate by date + resolved dish (or raw name if unmatched)
  const agg = new Map<string, ParsedSaleRow>();

  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (!row) continue;
    const rawName = String(row[5] ?? '').trim();
    if (!rawName) continue;

    const dateStr = coerceDate(row[1]);
    if (!dateStr) continue;

    const qty = parseFloat(row[7]) || 0;
    if (qty <= 0) continue;

    const match = matchDishByName(rawName, dishByLowerName);
    const key = `${dateStr}|${match.id ?? 'U:' + rawName}`;

    const existing = agg.get(key);
    if (existing) {
      existing.quantity += qty;
    } else {
      agg.set(key, {
        date: dateStr,
        rawName,
        dishId: match.id,
        dishName: match.name,
        quantity: qty,
        department: match.department,
      });
    }
  }

  return Array.from(agg.values());
}

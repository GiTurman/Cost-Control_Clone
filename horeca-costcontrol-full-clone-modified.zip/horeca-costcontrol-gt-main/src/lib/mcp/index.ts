import { defineMcp } from "@lovable.dev/mcp-js";
import foodCostTool from "./tools/food-cost";
import markupPriceTool from "./tools/markup-price";
import appInfoTool from "./tools/app-info";

export default defineMcp({
  name: "costcontrol-mcp",
  title: "CostControl MCP",
  version: "0.1.0",
  instructions:
    "Tools for the CostControl HORECA app. Use `get_app_info` to learn what the app tracks, `calculate_food_cost` to compute food-cost % and margin for a dish, and `suggest_sale_price` to derive a sale price from an ingredient cost and a target food-cost %.",
  tools: [appInfoTool, foodCostTool, markupPriceTool],
});

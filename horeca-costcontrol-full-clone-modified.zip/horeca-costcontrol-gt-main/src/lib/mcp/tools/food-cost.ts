import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";

export default defineTool({
  name: "calculate_food_cost",
  title: "Calculate food cost",
  description:
    "Calculate food cost percentage and profit margin from a dish's ingredient cost and sale price.",
  inputSchema: {
    ingredientCost: z.number().positive().describe("Total ingredient cost of the dish"),
    salePrice: z.number().positive().describe("Sale price of the dish"),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ ingredientCost, salePrice }) => {
    const foodCostPct = (ingredientCost / salePrice) * 100;
    const profit = salePrice - ingredientCost;
    const marginPct = (profit / salePrice) * 100;
    const text = [
      `Ingredient cost: ${ingredientCost.toFixed(2)}`,
      `Sale price: ${salePrice.toFixed(2)}`,
      `Profit: ${profit.toFixed(2)}`,
      `Food cost: ${foodCostPct.toFixed(2)}%`,
      `Margin: ${marginPct.toFixed(2)}%`,
    ].join("\n");
    return {
      content: [{ type: "text", text }],
      structuredContent: {
        ingredientCost,
        salePrice,
        profit,
        foodCostPct,
        marginPct,
      },
    };
  },
});

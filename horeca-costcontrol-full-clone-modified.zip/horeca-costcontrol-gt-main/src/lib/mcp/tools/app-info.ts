import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";

export default defineTool({
  name: "get_app_info",
  title: "Get app info",
  description:
    "Return information about CostControl — a HORECA cost-control app for restaurants and hotels (products, purchases, menu/dishes, sales, inventory, breakfast, housekeeping, technical).",
  inputSchema: {},
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: () => {
    const info = {
      name: "CostControl",
      description:
        "HORECA cost-control app for restaurants and hotels. Tracks products, purchases, menu recipes, sales, inventory audits, breakfast, housekeeping and technical consumption.",
      language: "Georgian (ka) / English (en)",
      departments: ["restaurant", "bar", "breakfast", "housekeeping", "technical"],
      modules: [
        "products",
        "purchases",
        "menu",
        "sales",
        "inventory",
        "ai-analytics",
        "classifier",
        "debtor",
        "breakfast",
        "housekeeping",
        "technical",
      ],
    };
    return {
      content: [{ type: "text", text: JSON.stringify(info, null, 2) }],
      structuredContent: info,
    };
  },
});

// keep z import used for type inference in defineTool
void z;

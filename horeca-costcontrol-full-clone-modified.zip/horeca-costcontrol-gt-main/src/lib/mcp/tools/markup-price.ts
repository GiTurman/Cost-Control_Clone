import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";

export default defineTool({
  name: "suggest_sale_price",
  title: "Suggest sale price",
  description:
    "Suggest a sale price for a dish given its ingredient cost and a target food cost percentage (e.g. 30 for 30%).",
  inputSchema: {
    ingredientCost: z.number().positive().describe("Total ingredient cost of the dish"),
    targetFoodCostPct: z
      .number()
      .positive()
      .max(100)
      .describe("Target food cost percentage (1-100)"),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: ({ ingredientCost, targetFoodCostPct }) => {
    const suggestedPrice = ingredientCost / (targetFoodCostPct / 100);
    const profit = suggestedPrice - ingredientCost;
    const text = [
      `Ingredient cost: ${ingredientCost.toFixed(2)}`,
      `Target food cost: ${targetFoodCostPct}%`,
      `Suggested sale price: ${suggestedPrice.toFixed(2)}`,
      `Profit per unit: ${profit.toFixed(2)}`,
    ].join("\n");
    return {
      content: [{ type: "text", text }],
      structuredContent: { ingredientCost, targetFoodCostPct, suggestedPrice, profit },
    };
  },
});

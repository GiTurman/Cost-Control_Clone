# Phase 7 Local Clone Import

This branch imports the uploaded fuller local HoReCa CostControl app as the GitHub Pages preview source.

The original local app remains untouched.

Expected result after deployment:

- fuller menu structure is visible;
- additional modules such as Breakfast, Chef, Classifier, Debtors, Housekeeping, Technical, Global Inventory, and Inventory Archive are present;
- GitHub Pages builds from this imported clone.
